<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends TexBase {

	public function __construct() {
		parent :: __construct();
		//$this->load->model('Dashboard_model','dashboard_model');
		$this->data["title"]="Home";
		$this->data["currentPage"]="dashboard";
		$this->load->library('curl');
	}

	public function index() {
		$this->data["title"]="Dashboard";
		$this->data["currentPage"]="dashboard";
		$this->templateFront("frontend/dashboard/index", $this->data, null);
	}

}
?>
