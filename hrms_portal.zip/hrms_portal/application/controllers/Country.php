<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Country extends TexBase
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Country_model', 'country_model');
        $this->data["title"] = "Home";
        $this->data["currentPage"] = "home";
        $this->load->library('curl');
    }

    public function getCountryList()
    {
        $countrylist = $this->country_model->getCountryList();
        $this->data["title"] = "Employee";
        $this->data["country"] = $countrylist;
        $this->templateFront("frontend/employee/countrylist", $this->data);
    }

    public function index()
    {
        $this->data["title"] = "Employee";
        $this->templateFront("frontend/employee/add-country", $this->data);
    }

    public function addcountry()
    {
       if($this->input->post('submit')){

            $this->country_model->addNewCountry();
        }
        else
        {
            redirect('country/getCountryList');
        }
    }
    public function deleteCountry($id)
    {
        if ($this->country_model->deactivateCountry($id)) {
            
        }
    }

    public function editcountry($id)
    {
        $eventlist = $this->country_model->checkEventdata($id);
        $this->data['eventdata'] = $eventlist;
        $this->data["title"] = "Employee";
        $this->templateFront("frontend/employee/edit-country", $this->data);
        
    }

    public function updateCountry()
    {
        if (isset($_POST['submit'])) {

            $this->country_model->updateCountry();
        } else {
            redirect('event/getEventList');
        }
    }
}
