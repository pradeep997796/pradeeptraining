<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class test2 extends TexBase {
public function index()
{
    $this-> templateFront('test1');
}
}
?>