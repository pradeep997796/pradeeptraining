<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class test extends TexBase {
public function index()
{
    redirect('test2');
}
}
?>