<?php
//error_reporting(0);
defined('BASEPATH') or exit('No direct script access allowed');

class Employee extends TexBase
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Employee_model', 'employee_model');
        $this->load->model('Project_model', 'project_model');
        $this->data["title"] = "Home";
        $this->data["currentPage"] = "home";
        $this->load->library('curl');
    }

    public function index()
    {
        redirect("employee/employeeList");
    }

    public function employeeList()
    {
        $employeeList = $this->employee_model->getEmployeeList();
        $this->data["title"] = "Employee";
        $this->data["employeeData"] = $employeeList;
        $this->templateFront("frontend/employee/employee-list", $this->data);
    }

    public function  addEmployee()
    {
        $this->data["title"] = "Employee";
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $validFlag = true;
            //echo "<pre>"; print_r($_POST);die;
            if (isset($_POST['officeemail']) && $_POST['officeemail'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUnique($_POST['officeemail'], 'businessEmail');
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Official Email Already Exists.");
                }
            }
            if (isset($_POST['email']) && $_POST['email'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUnique($_POST['email'], 'personalEmail');
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Personal Email Already Exists.");
                }
            }
            if (isset($_POST['mobileNumber']) && $_POST['mobileNumber'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUnique($_POST['mobileNumber'], 'personalContactNumber');
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Personal Mobile Already Exists.");
                }
            }
            if (isset($_POST['officemobileNumber']) && $_POST['officemobileNumber'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUnique($_POST['officemobileNumber'], 'businessContactNumber');
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Offial Email Already Exists.");
                }
            }
            if ($validFlag == false) {
                $this->templateFront("frontend/employee/add-employee", $this->data);
            } else {
                $objResult = $this->employee_model->addNewEmployee();
                if ($objResult) {
                    $this->session->set_flashdata('successMsg', "Employee saved successfully.");
                    redirect("employee/employeeList");
                } else {
                    $this->session->set_flashdata('errorMsg', "Employee doesn't saved, please try again.");
                    $this->templateFront("frontend/employee/add-employee", $this->data);
                }
            }
        } else {
            $this->templateFront("frontend/employee/add-employee", $this->data);
        }
    }

    public function deActivateEmployee()
    {
        $id = $this->input->post('id');
        $this->employee_model->deactivateEmployee($id);
        echo 1;
    }
    public function view($id = null)
    {
        if ($id) {
            $this->data["title"] = "View Employee";
            $this->data["currentPage"] = "view-employee";
            $objDetails = $this->employee_model->getEmployeeDetails($id);
            $objnationalInfo = $this->employee_model->getEmployeeNationalInfo($id);
            $objAddressInfo = $this->employee_model->getEmployeeAddressInfo($id);
            $objEducationInfo = $this->employee_model->getEmployeeEducationInfo($id);
            $objFinanceInfo = $this->employee_model->getEmployeeFinanceInfo($id);
            $objEmergencyInfo = $this->employee_model->getEmergencyInfo($id);
            $objDependentInfo = $this->employee_model->getDependentInfo($id);
            $objjobInfo = $this->employee_model->getJobInfo($id);
            $objInsuranceInfo = $this->employee_model->getEmployeeInsuranceInfo($id);
            $objEarning = $this->employee_model->getEarningInfo($id);
            $objDeduction = $this->employee_model->getDeductionInfo($id);
            $objEmployer = $this->employee_model->getEmployerContributionInfo($id);
            $objAccountInfo = $this->employee_model->getEmployerAccountInfo($id);

            //echo "<pre>"; print_r($objjobInfo);die;
            if ($objDetails) {
                $this->data["objDetails"] = $objDetails[0];
                $this->data["nationalInfo"] = $objnationalInfo;
                $this->data["addressInfo"] = $objAddressInfo;
                $this->data["educationInfo"] = $objEducationInfo;
                $this->data["financeInfo"] = $objFinanceInfo;
                $this->data["emergencyInfo"] = $objEmergencyInfo;
                $this->data["dependentInfo"] = $objDependentInfo;
                $this->data["jobInfo"] = $objjobInfo;
                $this->data['insuranceInfo'] = $objInsuranceInfo;
                $this->data['earningInfo'] = $objEarning;
                $this->data['deductionInfo'] = $objDeduction;
                $this->data['employerInfo'] = $objEmployer;
                $this->data['accountInfo'] = $objAccountInfo;

                //echo "<pre>"; print_r($objjobInfo);die;
                $this->templateFront("frontend/employee/view-employee", $this->data);
            } else {
                redirect("employee/employeeList");
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function getEmployeePersonalInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmployeePersonalInfo($id);
        $this->data['empinfo'] = $empinfo[0];
        $this->load->view('frontend/employee/personal-info', $this->data);
    }

    public function updatePersonalInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            $validFlag = true;
            //echo "<pre>"; print_r($_POST);die;
            if (isset($_POST['officeemail']) && $_POST['officeemail'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUniqueUpdate($_POST['officeemail'], 'businessEmail', $id);
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Official Email Already Exists.");
                }
            }
            if (isset($_POST['email']) && $_POST['email'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUniqueUpdate($_POST['email'], 'personalEmail', $id);
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Personal Email Already Exists.");
                }
            }
            if (isset($_POST['mobileNumber']) && $_POST['mobileNumber'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUniqueUpdate($_POST['mobileNumber'], 'personalContactNumber', $id);
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Personal Mobile Already Exists.");
                }
            }
            if (isset($_POST['officemobileNumber']) && $_POST['officemobileNumber'] != "" && $validFlag == true) {
                $objCheck = $this->employee_model->checkUniqueUpdate($_POST['officemobileNumber'], 'businessContactNumber', $id);
                if ($objCheck == 0) {
                    $validFlag = false;
                    $this->data['formValue'] = $this->input->post();
                    $this->session->set_flashdata('errorMsg', "This Offial Email Already Exists.");
                }
            }
            if ($validFlag == false) {
                redirect("employee/view/$id");
            } else {
                $objResult = $this->employee_model->updatePersonalInfo();
                if ($objResult) {
                    $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                    redirect("employee/view/$id");
                } else {
                    $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                    redirect("employee/view/$id");
                }
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function getEmployeeNationalInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmployeeNationalInfo($id);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/national-info', $this->data);
    }

    public function nationalinfoAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->load->view('frontend/employee/national-info-add-row', $this->data);
    }

    public function updateNationalInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            //echo "<pre>"; print_r($_FILES);die;
            // Count total files
            $countfiles = count($_FILES['attachment']['name']);
            // Looping all files
            for ($i = 0; $i < $countfiles; $i++) {
                if (!empty($_FILES['attachment']['name'][$i])) {

                    // Define new $_FILES array - $_FILES['file']
                    $_FILES['file']['name'] = $_FILES['attachment']['name'][$i];
                    $_FILES['file']['type'] = $_FILES['attachment']['type'][$i];
                    $_FILES['file']['tmp_name'] = $_FILES['attachment']['tmp_name'][$i];
                    $_FILES['file']['error'] = $_FILES['attachment']['error'][$i];
                    $_FILES['file']['size'] = $_FILES['attachment']['size'][$i];

                    if (!is_dir('uploads/' . $id)) {
                        mkdir('./uploads/' . $id, 0777, TRUE);
                    }
                    // Set preference
                    $config['upload_path'] = 'uploads/' . $id . '/';
                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config['max_size'] = '50000'; // max_size in kb
                    $config['file_name'] = strtotime(date("Y-m-d H:i:s")) . $_FILES['attachment']['name'][$i];

                    //Load upload library
                    $this->load->library('upload', $config);

                    // File upload
                    if ($this->upload->do_upload('file')) {
                        // Get data about the file
                        $uploadData = $this->upload->data();
                        $filename = $uploadData['file_name'];

                        // Initialize array
                        $data['filenames'][] = $filename;
                    }
                } else {
                    $data['filenames'][] = $_POST['attachmentName'][$i];
                }
            }
            $objResult = $this->employee_model->updateNationalInfo($data);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function deleteNationalinfo()
    {
        $id = $this->input->post('id');
        $objResult = $this->employee_model->deleteNationalinfo($id);
    }

    public function getEmployeeAddressInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmployeeAddressInfo($id);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/address-info', $this->data);
    }

    public function updateAddressInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');

            // Count total files
            $countfiles = count($_FILES['attachment']['name']);

            // Looping all files
            for ($i = 0; $i < $countfiles; $i++) {
                if (!empty($_FILES['attachment']['name'][$i])) {

                    // Define new $_FILES array - $_FILES['file']
                    $_FILES['file']['name'] = $_FILES['attachment']['name'][$i];
                    $_FILES['file']['type'] = $_FILES['attachment']['type'][$i];
                    $_FILES['file']['tmp_name'] = $_FILES['attachment']['tmp_name'][$i];
                    $_FILES['file']['error'] = $_FILES['attachment']['error'][$i];
                    $_FILES['file']['size'] = $_FILES['attachment']['size'][$i];

                    if (!is_dir('uploads/' . $id)) {
                        mkdir('./uploads/' . $id, 0777, TRUE);
                    }
                    // Set preference
                    $config['upload_path'] = 'uploads/' . $id . '/';
                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config['max_size'] = '50000'; // max_size in kb
                    $config['file_name'] = strtotime(date("Y-m-d H:i:s")) . $_FILES['attachment']['name'][$i];

                    //Load upload library
                    $this->load->library('upload', $config);

                    // File upload
                    if ($this->upload->do_upload('file')) {
                        // Get data about the file
                        $uploadData = $this->upload->data();
                        $filename = $uploadData['file_name'];

                        // Initialize array
                        $data['filenames'][] = $filename;
                    } else {
                        $error = array('error' => $this->upload->display_errors());
                    }
                } else {
                    $data['filenames'][] = $_POST['attachmentName'][$i];
                }
            }

            $objResult = $this->employee_model->updateAddressInfo($data);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function getEmployeeFinanceInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmployeeFinanceInfo($id);
        $insuranceInfo = $this->employee_model->getEmployeeInsuranceInfo($id);
        $this->data['insuranceinfo'] = $insuranceInfo;
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/finance-info', $this->data);
    }

    public function updateFinanceInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            // Looping all files
            $countfiles = count($_FILES['attachment']['name']);
            for ($i = 0; $i < $countfiles; $i++) {
                if (!empty($_FILES['attachment']['name'][$i])) {

                    // Define new $_FILES array - $_FILES['file']
                    $_FILES['file']['name'] = $_FILES['attachment']['name'][$i];
                    $_FILES['file']['type'] = $_FILES['attachment']['type'][$i];
                    $_FILES['file']['tmp_name'] = $_FILES['attachment']['tmp_name'][$i];
                    $_FILES['file']['error'] = $_FILES['attachment']['error'][$i];
                    $_FILES['file']['size'] = $_FILES['attachment']['size'][$i];

                    if (!is_dir('uploads/' . $id)) {
                        mkdir('./uploads/' . $id, 0777, TRUE);
                    }
                    // Set preference
                    $config['upload_path'] = 'uploads/' . $id . '/';
                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config['max_size'] = '50000'; // max_size in kb
                    $config['file_name'] = strtotime(date("Y-m-d H:i:s")) . $_FILES['attachment']['name'][$i];

                    //Load upload library
                    $this->load->library('upload', $config);

                    // File upload
                    if ($this->upload->do_upload('file')) {
                        // Get data about the file
                        $uploadData = $this->upload->data();
                        $filename = $uploadData['file_name'];

                        // Initialize array
                        $data['filenames'][] = $filename;
                    } else {
                        $error = array('error' => $this->upload->display_errors());
                    }
                } else {
                    $data['filenames'][] = $_POST['attachmentName'][$i];
                }
            }

            $objResult = $this->employee_model->updateFinanceInfo($data);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function getEmployeeEducationInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmployeeEducationInfo($id);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/education-info', $this->data);
    }
    public function educationinfoAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->load->view('frontend/employee/education-info-add-row', $this->data);
    }

    public function updateEducaationInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');

            // Count total files
            $countfiles = count($_FILES['attachment']['name']);
            // Looping all files
            for ($i = 0; $i < $countfiles; $i++) {
                if (!empty($_FILES['attachment']['name'][$i])) {

                    // Define new $_FILES array - $_FILES['file']
                    $_FILES['file']['name'] = $_FILES['attachment']['name'][$i];
                    $_FILES['file']['type'] = $_FILES['attachment']['type'][$i];
                    $_FILES['file']['tmp_name'] = $_FILES['attachment']['tmp_name'][$i];
                    $_FILES['file']['error'] = $_FILES['attachment']['error'][$i];
                    $_FILES['file']['size'] = $_FILES['attachment']['size'][$i];

                    if (!is_dir('uploads/' . $id)) {
                        mkdir('./uploads/' . $id, 0777, TRUE);
                    }
                    // Set preference
                    $config['upload_path'] = 'uploads/' . $id . '/';
                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                    $config['max_size'] = '50000'; // max_size in kb
                    $config['file_name'] = strtotime(date("Y-m-d H:i:s")) . $_FILES['attachment']['name'][$i];

                    //Load upload library
                    $this->load->library('upload', $config);

                    // File upload
                    if ($this->upload->do_upload('file')) {
                        // Get data about the file
                        $uploadData = $this->upload->data();
                        $filename = $uploadData['file_name'];

                        // Initialize array
                        $data['filenames'][] = $filename;
                    }
                } else {
                    $data['filenames'][] = $_POST['attachmentName'][$i];
                }
            }

            $objResult = $this->employee_model->updateEducationalInfo($data);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function getEmergencyInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getEmergencyInfo($id);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/emergency-contact', $this->data);
    }

    public function updateEmergencyInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');

            $objResult = $this->employee_model->updateEmergencyInfo();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function getDependentInfo()
    {
        $id = $this->input->post('id');
        $empinfo = $this->employee_model->getDependentInfo($id);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $id;
        $this->load->view('frontend/employee/dependent-info', $this->data);
    }

    public function dependentinfoAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->load->view('frontend/employee/dependent-info-add-row', $this->data);
    }

    public function updateDependentInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');

            $objResult = $this->employee_model->updateDependentInfo();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function deleteDependentInfo()
    {
        $id = $this->input->post('id');
        $objResult = $this->employee_model->deleteDependentInfo($id);
    }

    public function deleteEducationInfo()
    {
        $id = $this->input->post('id');
        $objResult = $this->employee_model->deleteEducationInfo($id);
    }
    public function loadJobInformation()
    {
        $empId = $this->input->post('empId');
        $empinfo = $this->employee_model->getJobInfo($empId);
        $objProjectList = $this->project_model->getAllProjects();
        $this->data['empinfo'] = $empinfo;
        $this->data['projectList'] = $objProjectList;
        $this->data['empid'] = $empId;
        $this->load->view('frontend/employee/job-information', $this->data);
    }

    public function loadAccountInformation()
    {
        $empId = $this->input->post('empId');
        $empinfo = $this->employee_model->getEmployerAccountInfo($empId);
        $this->data['empinfo'] = $empinfo;
        $this->data['empid'] = $empId;
        $this->load->view('frontend/employee/account-information', $this->data);
    }

    public function updateJobInformation()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            $objResult = $this->employee_model->updateJobInformation($id);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function updateAccountInformation()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            $objResult = $this->employee_model->updateAccountInformation($id);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function deleteAllNational($id = null)
    {
        $qb = $this->em->createQueryBuilder();
        $query = $qb->delete('DocumentProofMaster', 'dpf')
            ->where('dpf.emp = :id')
            ->setParameter('id', $id)
            ->getQuery();

        $query->execute();
    }

    public function updateProfilePhoto()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            if (!empty($_FILES['attachment']['name'])) {
                $_FILES['file']['name'] = $_FILES['attachment']['name'];
                $_FILES['file']['type'] = $_FILES['attachment']['type'];
                $_FILES['file']['tmp_name'] = $_FILES['attachment']['tmp_name'];
                $_FILES['file']['error'] = $_FILES['attachment']['error'];
                $_FILES['file']['size'] = $_FILES['attachment']['size'];

                if (!is_dir('uploads/' . $id)) {
                    mkdir('./uploads/' . $id, 0777, TRUE);
                }
                // Set preference
                $config['upload_path'] = 'uploads/' . $id . '/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['max_size'] = '50000'; // max_size in kb
                $config['file_name'] = strtotime(date("Y-m-d H:i:s")) . $_FILES['attachment']['name'];

                //Load upload library
                $this->load->library('upload', $config);
                // File upload
                if ($this->upload->do_upload('file')) {
                    // Get data about the file
                    $uploadData = $this->upload->data();
                    $filename = $uploadData['file_name'];

                    // Initialize array
                    $data['filenames'][] = $filename;
                } else {
                    $this->session->set_flashdata('errorMsg', "Please Upload Attachment With Valid Format.");
                    redirect("employee/view/$id");
                }
            }
            $objResult = $this->employee_model->updateProfilePhoto($data);
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        }
    }

    public function addSalaryInformation()
    {
        $empId = $this->input->post('empId');
        $empinfo = $this->employee_model->getJobInfo($empId);
        $objEarningInfo = $this->employee_model->getEarningInfo($empId);
        $objDeductionInfo = $this->employee_model->getDeductionInfo($empId);
        $objEmployerInfo = $this->employee_model->getEmployerInfo($empId);
        $this->data['earningInfo'] = $objEarningInfo;
        $this->data['deductionInfo'] = $objDeductionInfo;
        $this->data['employerInfo'] = $objEmployerInfo;
        $this->data['salaryTypeList'] = $this->employee_model->getsalaryTypeMaster();
        $this->data['empid'] = $empId;
        $this->load->view('frontend/employee/salary-info', $this->data);
    }

    public function earningAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->data['addtype'] = 1;
        $this->data['salaryTypeList'] = $this->employee_model->getsalaryTypeMaster();
        $this->load->view('frontend/employee/salary-info-add-row', $this->data);
    }

    public function deductionAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->data['addtype'] = 0;
        $this->data['salaryTypeList'] = $this->employee_model->getsalaryTypeMaster();
        $this->load->view('frontend/employee/salary-info-add-row', $this->data);
    }

    public function employerAddRow()
    {
        $id = $this->input->post('id');
        $this->data['id'] = $id;
        $this->data['addtype'] = 2;
        $this->data['salaryTypeList'] = $this->employee_model->getsalaryTypeMaster();
        $this->load->view('frontend/employee/salary-info-add-row', $this->data);
    }

    public function addEmployeeSalaryInfo()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('employeeid');
            $objResult = $this->employee_model->addEmployeeSalaryInfo();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Updated successfully.");
                redirect("employee/view/$id");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Not Updated, please try again.");
                redirect("employee/view/$id");
            }
        } else {
            redirect("employee/employeeList");
        }
    }

    public function deleteDeductioninfo()
    {
        $id = $this->input->post('id');
        $objResult = $this->employee_model->deleteDeductioninfo($id);
    }

    public function deleteEmployerinfo()
    {
        $id = $this->input->post('id');
        $objResult = $this->employee_model->deleteEmployerinfo($id);
    }
    public function deleteEmployeeSalary($id = null)
    {
        $objResult = $this->employee_model->deleteEmployeeSalary($id);
    }

    public function getEmployeeleavesBalance()
    {
        $empid = $this->input->post('empid');

        $leavesBalance = $this->employee_model->getEmployeeleavesBalance($empid);
        $this->data['leavesBalance'] = $leavesBalance;
        $this->load->view('frontend/employee/leave-balance-info', $this->data);
    }
}
