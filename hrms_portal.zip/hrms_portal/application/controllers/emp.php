<?php

defined('BASEPATH') or exit('No direct script access allowed');

class emp extends TexBase
{
    public function __construct()
    {
        parent::__construct();
        // $this->load->model('emp_model', 'emp_model');
        $this->data["title"] = "Home";
        $this->data["currentPage"] = "home";
        $this->load->library('curl');
    }

    public function emplist()
    {
        //  $empList = $this->emp_model->getEmpList();
        $this->data["title"] = "Employee";
        //  $this->data["employeeData"] = $empList;
        $this->templateFront("frontend/employee/emp-list", $this->data);
    }

    public function index()
    {
        $this->data["title"] = "Employee";
        $this->templateFront("frontend/employee/add-emp", $this->data);
    }

    public function addemp()
    {
        $this->data["title"] = "Employee";
        if (isset($_POST['Name']) && $_POST['Name'] != "") {
                $this->data['formValue'] = $this->input->post();
                
            }

            if (isset($_POST['mobileNumber']) && $_POST['mobileNumber'] != "") {
                $this->data['formValue'] = $this->input->post();
                
            }

            if (isset($_POST['employeeId']) && $_POST['employeeId'] != "") {
                $this->data['formValue'] = $this->input->post();
                
            }

            if (isset($_POST['gender']) && $_POST['gender'] != "") {
                $this->data['formValue'] = $this->input->post();
                
            }

            if (isset($_POST['dateOfBirth']) && $_POST['dateOfBirth'] != "") {
                $this->data['formValue'] = $this->input->post();
            }
        }
    
    }

?>