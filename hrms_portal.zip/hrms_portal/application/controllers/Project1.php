<?php
//error_reporting(0);
defined('BASEPATH') or exit('No direct script access allowed');

class Project extends TexBase
{
    public function __construct()
    {
        parent :: __construct();
        $this->load->model('Project_model', 'project_model');
        $this->load->model('Hr_model', 'hr_model');
        $this->data["title"]="Project";
        $this->data["currentPage"]="home";
        $this->load->library('curl');
        $this->load->library('UnqPHPExcel');
    }

    public function index()
    {
        redirect("project/projectList");
    }

    public function projectList()
    {
        $this->data["title"]="Project";
        $this->data["listData"] = $this->project_model->getAllProjects();
        $this->templateFront("frontend/project/list", $this->data);
    }

    public function addProject()
    {
        if (isset($_POST['submit'])) {
            $this->project_model->saveNewProject($_POST);
            redirect("project/projectList");
        } else {
            $this->data["title"]="Project";
            $this->data["projectData"] = [];
            $this->templateFront("frontend/project/addProject", $this->data);
        }
    }

    public function updateProject()
    {
        if (isset($_POST['submit'])) {
            $this->project_model->updateProject($_POST);
            redirect("project/projectList");
        } else {
            $projectid = $this->uri->segment(3);
            $projectData = $this->project_model->getProjectData($projectid);
            $this->data["title"]="Project";
            $this->data["projectData"] = $projectData;
            $this->templateFront("frontend/project/updateProject", $this->data);
        }
    }

    public function deactivateProject()
    {
        $id = $this->input->post('id');
        $this->project_model->deactivateProject($id);
    }

    public function viewProjectSalary($id=null)
    {
        if ($id) {
            $objEmployeeData = $this->project_model->getProjectEmployeeSalary($id);
            $objProjectData = $this->project_model->getProjectData($id);
            $this->data["title"]="Project";
            $this->data["projectname"]= $objProjectData[0]->getName();
            $this->data["salaryData"] = $objEmployeeData;
            $this->data["projectid"] = $id;
            $this->templateFront("frontend/project/projectwise-salary-list", $this->data);
        } else {
            redirect('project/projectList');
        }
    }

    public function generateSalaryReport($id=null)
    {
        if ($id) {
            $objEmployeeData = $this->project_model->getProjectEmployeeSalary($id);
            $objProjectData = $this->project_model->getProjectData($id);

            $objExcel = $this->unqphpexcel->getPHPExelObject();
            $objExcel->setActiveSheetIndex(0);
            $objExcel->getActiveSheet()->setTitle('Emplyoee Salary');
            $objExcel->getActiveSheet()->getCell('A1')->setValue("S.No.");
            $objExcel->getActiveSheet()->getCell('B1')->setValue("Employee Name");
            $objExcel->getActiveSheet()->getCell('C1')->setValue("Earning");
            $objExcel->getActiveSheet()->getCell('D1')->setValue("Deduction");
            $objExcel->getActiveSheet()->getCell('E1')->setValue("Employer Contribution");
            $objExcel->getActiveSheet()->getCell('F1')->setValue("Net Salary");
            $index = 2;

            foreach ($objEmployeeData as $data) {
                $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
                $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data->getEmp()->getFirstName()." ".$data->getEmp()->getMiddleName()." ".$data->getEmp()->getLastName());
                $objExcel->getActiveSheet()->getCell('C' . $index)->setValue($data->getTotalEarning());
                $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($data->getTotalDeduction());
                $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($data->getEmployerAmount());
                $objExcel->getActiveSheet()->getCell('F' . $index)->setValue($data->getNetSalary());

                //Setting Border & Allignment to Data
                $objExcel->getActiveSheet()->getStyle('A'.$index.':F'.$index.'')->applyFromArray(
                    array(
                  'alignment' => array(
                      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                  ),
                  'borders' => array(
                      'allborders' => array(
                           'style' => PHPExcel_Style_Border::BORDER_THIN,
                       )
                  )
              )
              );
                $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
                $index++;
            }
            $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
            $objExcel->getActiveSheet()->protectCells('A1:F1', 'PHPExcel');
            $objExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray(
                array(
                  'font'    => array(
                      'bold'      => true
                  ),
                  'alignment' => array(
                      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                  ),
                  'borders' => array(
                      'allborders' => array(
                           'style' => PHPExcel_Style_Border::BORDER_THIN,
                       )
                  )
              )
              );
            $objExcel->getActiveSheet()->getStyle('A1:F1')->getFill()->applyFromArray(array(
                  'type' => PHPExcel_Style_Fill::FILL_SOLID,
                  'startcolor' => array(
                       'rgb' => 'b5bee0'
                  )
              ));
            $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(40);
            $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);


            //code For Second Sheet
            $objExcel->createSheet();
            $objExcel->setActiveSheetIndex(1);
            $objExcel->getActiveSheet()->setTitle('Test');
            $objExcel->getActiveSheet()->getCell('A1')->setValue("Sno");
            $objExcel->getActiveSheet()->getCell('B1')->setValue("Name");
            $objExcel->getActiveSheet()->getCell('C1')->setValue("City");
            $objExcel->getActiveSheet()->getCell('D1')->setValue("Address");
            $index = 2;
            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue('1');
            $objExcel->getActiveSheet()->getCell('B' . $index)->setValue('Soumen');
            $objExcel->getActiveSheet()->getCell('C' . $index)->setValue('Jbp');
            $objExcel->getActiveSheet()->getCell('D' . $index)->setValue('city jbp');

            $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
            $objExcel->getActiveSheet()->protectCells('A1:D1', 'PHPExcel');
            $objExcel->getActiveSheet()->getStyle('A1:D1')->applyFromArray(
                array(
                   'font'    => array(
                       'bold'      => true
                   ),
                   'alignment' => array(
                       'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                   ),
                   'borders' => array(
                       'allborders' => array(
                            'style' => PHPExcel_Style_Border::BORDER_THIN,
                        )
                   )
               )
               );
            $objExcel->getActiveSheet()->getStyle('A1:D1')->getFill()->applyFromArray(array(
                   'type' => PHPExcel_Style_Fill::FILL_SOLID,
                   'startcolor' => array(
                        'rgb' => 'b5bee0'
                   )
               ));


            $filename = $objProjectData[0]->getName()."_salary_".date('d_m_Y H:i:s');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename=' . $filename . '.xls');
            header('Cache-Control: max-age=0');
            $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
            $objWriter->save('php://output');
        } else {
            return false;
        }
    }

    public function generateBankSheetForSalary($id=null)
    {
        if ($id) {
            $objEmployeeData = $this->project_model->generateBankSheetForSalary($id);
            //$objProjectData = $this->project_model->getProjectData($id);

            $currentdate = date('d');
            if ($currentdate <= 25) {
                $salaryCircle =  date('M ,Y', strtotime("-1 month"));
            } else {
                $salaryCircle = date('M ,Y');
            }
            $objEmployeeDataIdbi = $objEmployeeData['idbi'];
            $objEmployeeDataNonIdbi = $objEmployeeData['nonidbi'];

            $totalSalary = 0;
            $totalSalaryIdbi = 0;
            //die;
            $objExcel = $this->unqphpexcel->getPHPExelObject();
            $objExcel->setActiveSheetIndex(0);
            $objExcel->getActiveSheet()->setTitle('IDBI To Others');
            $objExcel->getActiveSheet()->getCell('A1')->setValue("S No");
            $objExcel->getActiveSheet()->getCell('B1')->setValue("Amount");
            $objExcel->getActiveSheet()->getCell('C1')->setValue("A/c No To Debit");
            $objExcel->getActiveSheet()->getCell('D1')->setValue("Benificiary IFSC");
            $objExcel->getActiveSheet()->getCell('E1')->setValue("Benificiary A/C No");
            $objExcel->getActiveSheet()->getCell('F1')->setValue("Type Of A/c");
            $objExcel->getActiveSheet()->getCell('G1')->setValue("Benificiary Name");
            $objExcel->getActiveSheet()->getCell('H1')->setValue("A/c Branch");
            $objExcel->getActiveSheet()->getCell('I1')->setValue("Details Of Transaction");
            $objExcel->getActiveSheet()->getCell('J1')->setValue("A/c Name Debited");
            $objExcel->getActiveSheet()->getCell('K1')->setValue("Benificiary Bank");
            $objExcel->getActiveSheet()->getCell('L1')->setValue("Office Name");
            $index = 2;

            foreach ($objEmployeeDataNonIdbi as $data) {
                $totalSalary = $totalSalary + $data['netSalary'];

                $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
                $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data['netSalary']);
                $objExcel->getActiveSheet()->getCell('C' . $index)->setValue('0030102000037606');
                $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($data['ifsc']);
                $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($data['accountNumber']);
                $objExcel->getActiveSheet()->getCell('F' . $index)->setValue(10);
                $objExcel->getActiveSheet()->getCell('G' . $index)->setValue($data['firstName']." ".$data['middleName']." ".$data['lastName']);
                $objExcel->getActiveSheet()->getCell('H' . $index)->setValue($data['branch']);
                $objExcel->getActiveSheet()->getCell('I' . $index)->setValue('Salary For The Month Of '.$salaryCircle);
                $objExcel->getActiveSheet()->getCell('J' . $index)->setValue('Katyayani telecom services Pvt. Ltd');
                $objExcel->getActiveSheet()->getCell('K' . $index)->setValue($data['bankName']);
                $objExcel->getActiveSheet()->getCell('L' . $index)->setValue($data['name']);

                //Setting Border & Allignment to Data
                $objExcel->getActiveSheet()->getStyle('A'.$index.':L'.$index.'')->applyFromArray(
                    array(
                  'alignment' => array(
                      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                  ),
                  'borders' => array(
                      'allborders' => array(
                           'style' => PHPExcel_Style_Border::BORDER_THIN,
                       )
                  )
              )
              );
                $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
                $index++;
            }
            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue('Total Amount');
            $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($totalSalary);
            $objExcel->getActiveSheet()->mergeCells('C' . $index.':L'.$index);
            $objExcel->getActiveSheet()->getCell('C' . $index)->setValue(ucwords($this->getIndianCurrency($totalSalary)));
            $objExcel->getActiveSheet()->getStyle('A' . $index.':L'.$index)->applyFromArray(
                array(
              'font'    => array(
                   'bold'      => true
               ),
               'alignment' => array(
                   'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
               ),
               'borders' => array(
                   'allborders' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN,
                    )
               )
           )
           );
            $objExcel->getActiveSheet()->getStyle('A' . $index.':L'.$index)->getFill()->applyFromArray(array(
                 'type' => PHPExcel_Style_Fill::FILL_SOLID,
                 'startcolor' => array(
                      'rgb' => 'f4d03f'
                 )
             ));
            $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
            $objExcel->getActiveSheet()->protectCells('A1:L1', 'PHPExcel');
            $objExcel->getActiveSheet()->getStyle('A1:L1')->applyFromArray(
                array(
                  'font'    => array(
                      'bold'      => true
                  ),
                  'alignment' => array(
                      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                  ),
                  'borders' => array(
                      'allborders' => array(
                           'style' => PHPExcel_Style_Border::BORDER_THIN,
                       )
                  )
              )
              );
            $objExcel->getActiveSheet()->getStyle('A1:L1')->getFill()->applyFromArray(array(
                  'type' => PHPExcel_Style_Fill::FILL_SOLID,
                  'startcolor' => array(
                       'rgb' => 'b5bee0'
                  )
              ));
            $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
            $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(25);
            $objExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
            $objExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
            $objExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
            $objExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);

            //code For Second Sheet
            $objExcel->createSheet();
            $objExcel->setActiveSheetIndex(1);
            $objExcel->getActiveSheet()->setTitle('IDBI To IDBI');

            $objExcel->getActiveSheet()->getCell('A1')->setValue("S No");
            $objExcel->getActiveSheet()->getCell('B1')->setValue("Account Name");
            $objExcel->getActiveSheet()->getCell('C1')->setValue("Accounts Number");
            $objExcel->getActiveSheet()->getCell('D1')->setValue("Amount");
            $objExcel->getActiveSheet()->getCell('E1')->setValue("Project Name");
            $index = 2;

            foreach ($objEmployeeDataIdbi as $data) {
                $totalSalaryIdbi = $totalSalaryIdbi + + $data['netSalary'];

                $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
                $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data['firstName']." ".$data['middleName']." ".$data['lastName']);
                $objExcel->getActiveSheet()->getCell('C' . $index)->setValue($data['accountNumber']);
                $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($data['netSalary']);
                $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($data['name']);

                //Setting Border & Allignment to Data
                $objExcel->getActiveSheet()->getStyle('A'.$index.':E'.$index.'')->applyFromArray(
                    array(
                          'alignment' => array(
                              'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                          ),
                          'borders' => array(
                              'allborders' => array(
                                   'style' => PHPExcel_Style_Border::BORDER_THIN,
                               )
                          )
                      )
                      );
                $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
                $index++;
            }

            $objExcel->getActiveSheet()->mergeCells('A' . $index.':C'.$index);
            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue(ucwords($this->getIndianCurrency($totalSalaryIdbi)));
            $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($totalSalaryIdbi);
            $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($totalSalary+$totalSalaryIdbi);

            $objExcel->getActiveSheet()->getStyle('A' . $index.':E'.$index)->applyFromArray(
                   array(
              'font'    => array(
                   'bold'      => true
               ),
               'alignment' => array(
                   'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
               ),
               'borders' => array(
                   'allborders' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN,
                    )
               )
           )
           );

            $objExcel->getActiveSheet()->getStyle('A' . $index.':E'.$index)->getFill()->applyFromArray(array(
                 'type' => PHPExcel_Style_Fill::FILL_SOLID,
                 'startcolor' => array(
                      'rgb' => 'f4d03f'
                 )
             ));

            $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
            $objExcel->getActiveSheet()->protectCells('A1:E1', 'PHPExcel');
            $objExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray(
                 array(
                   'font'    => array(
                       'bold'      => true
                   ),
                   'alignment' => array(
                       'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                   ),
                   'borders' => array(
                       'allborders' => array(
                            'style' => PHPExcel_Style_Border::BORDER_THIN,
                        )
                   )
               )
               );
            $objExcel->getActiveSheet()->getStyle('A1:E1')->getFill()->applyFromArray(array(
                   'type' => PHPExcel_Style_Fill::FILL_SOLID,
                   'startcolor' => array(
                        'rgb' => 'b5bee0'
                   )
               ));

            $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
            $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(25);
            $objExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
            $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
            $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);

            $filename = $objEmployeeDataNonIdbi[0]['name']."_salary_".date('d_m_Y');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename=' . $filename . '.xls');
            header('Cache-Control: max-age=0');
            $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
            $objWriter->save('php://output');
        } else {
            return false;
        }
    }

    public function generateBankSheetForAllEmployees()
    {
        $objEmployeeData = $this->project_model->generateBankSheetForAllEmployees();
        $currentdate = date('d');
        if ($currentdate <= 25) {
            $salaryCircle =  date('M ,Y', strtotime("-1 month"));
        } else {
            $salaryCircle = date('M ,Y');
        }

        $objEmployeeDataIdbi = $objEmployeeData['idbi'];
        $objEmployeeDataNonIdbi = $objEmployeeData['nonidbi'];

        $totalSalary = 0;
        $totalSalaryIdbi = 0;

        $objExcel = $this->unqphpexcel->getPHPExelObject();
        $objExcel->setActiveSheetIndex(0);
        $objExcel->getActiveSheet()->setTitle('IDBI To Others');
        $objExcel->getActiveSheet()->getCell('A1')->setValue("S No");
        $objExcel->getActiveSheet()->getCell('B1')->setValue("Amount");
        $objExcel->getActiveSheet()->getCell('C1')->setValue("A/c No To Debit");
        $objExcel->getActiveSheet()->getCell('D1')->setValue("Benificiary IFSC");
        $objExcel->getActiveSheet()->getCell('E1')->setValue("Benificiary A/C No");
        $objExcel->getActiveSheet()->getCell('F1')->setValue("Type Of A/c");
        $objExcel->getActiveSheet()->getCell('G1')->setValue("Benificiary Name");
        $objExcel->getActiveSheet()->getCell('H1')->setValue("A/c Branch");
        $objExcel->getActiveSheet()->getCell('I1')->setValue("Details Of Transaction");
        $objExcel->getActiveSheet()->getCell('J1')->setValue("A/c Name Debited");
        $objExcel->getActiveSheet()->getCell('K1')->setValue("Benificiary Bank");
        $objExcel->getActiveSheet()->getCell('L1')->setValue("Office Name");
        $index = 2;

        foreach ($objEmployeeDataNonIdbi as $data) {
            $totalSalary = $totalSalary + $data['netSalary'];

            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
            $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data['netSalary']);
            $objExcel->getActiveSheet()->getCell('C' . $index)->setValue('0030102000037606');
            $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($data['ifsc']);
            $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($data['accountNumber']);
            $objExcel->getActiveSheet()->getCell('F' . $index)->setValue(10);
            $objExcel->getActiveSheet()->getCell('G' . $index)->setValue($data['firstName']." ".$data['middleName']." ".$data['lastName']);
            $objExcel->getActiveSheet()->getCell('H' . $index)->setValue($data['branch']);
            $objExcel->getActiveSheet()->getCell('I' . $index)->setValue('Salary For The Month Of '.$salaryCircle);
            $objExcel->getActiveSheet()->getCell('J' . $index)->setValue('Katyayani telecom services Pvt. Ltd');
            $objExcel->getActiveSheet()->getCell('K' . $index)->setValue($data['bankName']);
            $objExcel->getActiveSheet()->getCell('L' . $index)->setValue($data['name']);

            //Setting Border & Allignment to Data
            $objExcel->getActiveSheet()->getStyle('A'.$index.':L'.$index.'')->applyFromArray(
                array(
              'alignment' => array(
                  'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
              ),
              'borders' => array(
                  'allborders' => array(
                       'style' => PHPExcel_Style_Border::BORDER_THIN,
                   )
              )
          )
          );
            $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
            $index++;
        }
        $objExcel->getActiveSheet()->getCell('A' . $index)->setValue('Total Amount');
        $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($totalSalary);
        $objExcel->getActiveSheet()->mergeCells('C' . $index.':L'.$index);
        $objExcel->getActiveSheet()->getCell('C' . $index)->setValue(ucwords($this->getIndianCurrency($totalSalary)));
        $objExcel->getActiveSheet()->getStyle('A' . $index.':L'.$index)->applyFromArray(
            array(
          'font'    => array(
               'bold'      => true
           ),
           'alignment' => array(
               'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
           ),
           'borders' => array(
               'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                )
           )
       )
       );
        $objExcel->getActiveSheet()->getStyle('A' . $index.':L'.$index)->getFill()->applyFromArray(array(
             'type' => PHPExcel_Style_Fill::FILL_SOLID,
             'startcolor' => array(
                  'rgb' => 'f4d03f'
             )
         ));
        $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
        $objExcel->getActiveSheet()->protectCells('A1:L1', 'PHPExcel');
        $objExcel->getActiveSheet()->getStyle('A1:L1')->applyFromArray(
            array(
              'font'    => array(
                  'bold'      => true
              ),
              'alignment' => array(
                  'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
              ),
              'borders' => array(
                  'allborders' => array(
                       'style' => PHPExcel_Style_Border::BORDER_THIN,
                   )
              )
          )
          );
        $objExcel->getActiveSheet()->getStyle('A1:L1')->getFill()->applyFromArray(array(
              'type' => PHPExcel_Style_Fill::FILL_SOLID,
              'startcolor' => array(
                   'rgb' => 'b5bee0'
              )
          ));
        $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
        $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(25);
        $objExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
        $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
        $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
        $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
        $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
        $objExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
        $objExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
        $objExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
        $objExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
        $objExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
        $objExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
        $objExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);

        //code For Second Sheet
        $objExcel->createSheet();
        $objExcel->setActiveSheetIndex(1);
        $objExcel->getActiveSheet()->setTitle('IDBI To IDBI');

        $objExcel->getActiveSheet()->getCell('A1')->setValue("S No");
        $objExcel->getActiveSheet()->getCell('B1')->setValue("Account Name");
        $objExcel->getActiveSheet()->getCell('C1')->setValue("Accounts Number");
        $objExcel->getActiveSheet()->getCell('D1')->setValue("Amount");
        $objExcel->getActiveSheet()->getCell('E1')->setValue("Project Name");
        $index = 2;

        foreach ($objEmployeeDataIdbi as $data) {
            $totalSalaryIdbi = $totalSalaryIdbi + + $data['netSalary'];

            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
            $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data['firstName']." ".$data['middleName']." ".$data['lastName']);
            $objExcel->getActiveSheet()->getCell('C' . $index)->setValue($data['accountNumber']);
            $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($data['netSalary']);
            $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($data['name']);

            //Setting Border & Allignment to Data
            $objExcel->getActiveSheet()->getStyle('A'.$index.':E'.$index.'')->applyFromArray(
                array(
                      'alignment' => array(
                          'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                      ),
                      'borders' => array(
                          'allborders' => array(
                               'style' => PHPExcel_Style_Border::BORDER_THIN,
                           )
                      )
                  )
                  );
            $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
            $index++;
        }

        $objExcel->getActiveSheet()->mergeCells('A' . $index.':C'.$index);
        $objExcel->getActiveSheet()->getCell('A' . $index)->setValue(ucwords($this->getIndianCurrency($totalSalaryIdbi)));
        $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($totalSalaryIdbi);
        $objExcel->getActiveSheet()->getCell('E' . $index)->setValue($totalSalary+$totalSalaryIdbi);

        $objExcel->getActiveSheet()->getStyle('A' . $index.':E'.$index)->applyFromArray(
               array(
          'font'    => array(
               'bold'      => true
           ),
           'alignment' => array(
               'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
           ),
           'borders' => array(
               'allborders' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                )
           )
       )
       );

        $objExcel->getActiveSheet()->getStyle('A' . $index.':E'.$index)->getFill()->applyFromArray(array(
             'type' => PHPExcel_Style_Fill::FILL_SOLID,
             'startcolor' => array(
                  'rgb' => 'f4d03f'
             )
         ));

        $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
        $objExcel->getActiveSheet()->protectCells('A1:E1', 'PHPExcel');
        $objExcel->getActiveSheet()->getStyle('A1:E1')->applyFromArray(
             array(
               'font'    => array(
                   'bold'      => true
               ),
               'alignment' => array(
                   'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
               ),
               'borders' => array(
                   'allborders' => array(
                        'style' => PHPExcel_Style_Border::BORDER_THIN,
                    )
               )
           )
           );
        $objExcel->getActiveSheet()->getStyle('A1:E1')->getFill()->applyFromArray(array(
               'type' => PHPExcel_Style_Fill::FILL_SOLID,
               'startcolor' => array(
                    'rgb' => 'b5bee0'
               )
           ));

        $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
        $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(25);
        $objExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
        $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
        $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
        $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
        $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);

        $filename = $objEmployeeDataNonIdbi[0]['name']."_salary_".date('d_m_Y');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename=' . $filename . '.xls');
        header('Cache-Control: max-age=0');
        $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
        $objWriter->save('php://output');
    }

    public function generateBanksheetProjectWiseStructure($id)
    {
        if ($id) {
            $objEmployeeData = $this->project_model->generateBanksheetProjectWiseStructure($id);
            //$objProjectData = $this->project_model->getProjectData($id);
            $obJsalaryMasterArray = $this->hr_model->getSalaryStructureList();
            $staticArray = array('0' => 'H1',
                               '1' =>'I1',
                               '2' =>'J1',
                               '3' =>'K1',
                               '4' =>'L1',
                               '5' =>'M1',
                               '6' =>'N1',
                               '7' =>'O1',
                               '8' =>'P1',
                               '9' =>'Q1',
                               '10' =>'R1',
                               '11' =>'S1',
                               '12' =>'T1',
                               '13' =>'U1',
                               '14' =>'V1',
                               '15' =>'W1',
                               '16' =>'X1',
                               '17' =>'Y1',
                               '18' =>'Z1',
                               '19' =>'AA1',
                               '20' =>'AB1',
                               '21' =>'AC1',
                               '22' =>'AD1',
                               '23' =>'AE1',
                               '24' =>'AF1',
                               '25' =>'AG1',
                               '26' =>'AH1',
                               '27' =>'AI1',
                               '28' =>'AJ1',
                               '29' =>'AK1',
                               '30' =>'AL1',
                               '31' =>'AM1',
                               '32' =>'AN1',
                               '33' =>'AO1',
                               '34' =>'AP1',
                               '35' =>'AQ1',
                               '36' =>'AR1',
                               '37' =>'AS1',
                               '38' =>'AT1',
                              );
            $staticArrayData = array('0' =>'H',
                               '1' =>'I',
                               '2' =>'J',
                               '3' =>'K',
                               '4' =>'L',
                               '5' =>'M',
                               '6' =>'N',
                               '7' =>'O',
                               '8' =>'P',
                               '9' =>'Q',
                               '10' =>'R',
                               '11' =>'S',
                               '12' =>'T',
                               '13' =>'U',
                               '14' =>'V',
                               '15' =>'W',
                               '16' =>'X',
                               '17' =>'Y',
                               '18' =>'Z',
                               '19' =>'AA',
                               '20' =>'AB',
                               '21' =>'AC',
                               '22' =>'AD',
                               '23' =>'AE',
                               '24' =>'AF',
                               '25' =>'AG',
                               '26' =>'AH',
                               '27' =>'AI',
                               '28' =>'AJ',
                               '29' =>'AK',
                               '30' =>'AL',
                               '31' =>'AM',
                               '32' =>'AN',
                               '33' =>'AO',
                               '34' =>'AP',
                               '35' =>'AQ',
                               '36' =>'AR',
                               '37' =>'AS',
                               '38' =>'AT',
                              );
            $coloumnIdMapArray = [];

            $currentdate = date('d');
            if ($currentdate <= 25) {
                $salaryCircle =  date('M ,Y', strtotime("-1 month"));
            } else {
                $salaryCircle = date('M ,Y');
            }
            $currentdate = date('d');
            if ($currentdate <= 25) {
                $month = date('m') - 1;
            } else {
                $month = date('m');
            }
            //$month = date('m');
            $year = date('yy');
            $totaldays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
            $objEmployeeDataIdbi = $objEmployeeData;
            //$objEmployeeDataNonIdbi = $objEmployeeData['nonidbi'];

            $totalSalary = 0;
            $totalSalaryIdbi = 0;
            //die;
            $objExcel = $this->unqphpexcel->getPHPExelObject();
            $objExcel->setActiveSheetIndex(0);
            $objExcel->getActiveSheet()->setTitle('Employee Salary');
            $objExcel->getActiveSheet()->getCell('A1')->setValue("S No");
            $objExcel->getActiveSheet()->getCell('B1')->setValue("Location");
            $objExcel->getActiveSheet()->getCell('C1')->setValue("Name Of Candidate");
            $objExcel->getActiveSheet()->getCell('D1')->setValue("Days In Month");
            $objExcel->getActiveSheet()->getCell('E1')->setValue("LWP");
            $objExcel->getActiveSheet()->getCell('F1')->setValue("Present Days");
            $objExcel->getActiveSheet()->getCell('G1')->setValue("Salary NTH");

            for($i = 0; $i < count($obJsalaryMasterArray); $i++)
            {
               $objExcel->getActiveSheet()->getCell($staticArray[$i])->setValue($obJsalaryMasterArray[$i]->getName());
            }
            $index = 2;

            foreach ($objEmployeeDataIdbi as $data) {
                $totalSalary = $totalSalary + $data['netSalary'];

                $objExcel->getActiveSheet()->getCell('A' . $index)->setValue($index-1);
                $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($data['location']);
                $objExcel->getActiveSheet()->getCell('C' . $index)->setValue($data['firstName']." ".$data['middleName']." ".$data['lastName']);
                $objExcel->getActiveSheet()->getCell('D' . $index)->setValue($totaldays);
                $objExcel->getActiveSheet()->getCell('E' . $index)->setValue(0);
                if($data['leaves'] == "")
                {
                   $presentdays = $totaldays;
                }
                else {
                  $presentdays = $totaldays - $data['leaves'];
                }
                $objExcel->getActiveSheet()->getCell('F' . $index)->setValue($presentdays);
                $objExcel->getActiveSheet()->getCell('G' . $index)->setValue($data['netSalary']);

                //getting the Salary structure Wise Data
                $objEpmSalObj = $this->getCurrentMonthSalaryAll($data['id']);

                for($i = 0; $i < count($obJsalaryMasterArray); $i++)
                {
                    $flag = false;
                    foreach($objEpmSalObj as $salValue)
                    {

                        if($salValue->getSalaryType2()->getId() == $obJsalaryMasterArray[$i]->getId())
                        {
                            $objExcel->getActiveSheet()->getCell($staticArrayData[$i] . $index)->setValue($salValue->getAmount());
                            $flag = true;
                            break;
                        }
                    }
                    if($flag == false)
                    {
                       $objExcel->getActiveSheet()->getCell($staticArrayData[$i] . $index)->setValue(0);
                    }

                }

                //Setting Border & Allignment to Data
                $objExcel->getActiveSheet()->getStyle('A'.$index.':'.$staticArrayData[$i].$index.'')->applyFromArray(
                  array(
                'alignment' => array(
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                ),
                'borders' => array(
                    'allborders' => array(
                         'style' => PHPExcel_Style_Border::BORDER_THIN,
                     )
                )
            )
            );
                $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(20);
                $index++;
            }
            $objExcel->getActiveSheet()->getCell('A' . $index)->setValue('Total Amount');
            $objExcel->getActiveSheet()->getCell('B' . $index)->setValue($totalSalary);
            $objExcel->getActiveSheet()->mergeCells('C' . $index.':L'.$index);
            $objExcel->getActiveSheet()->getCell('C' . $index)->setValue(ucwords($this->getIndianCurrency($totalSalary)));
            $objExcel->getActiveSheet()->getStyle('A' . $index.':'.$staticArrayData[$i].$index)->applyFromArray(
              array(
            'font'    => array(
                 'bold'      => true
             ),
             'alignment' => array(
                 'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
             ),
             'borders' => array(
                 'allborders' => array(
                      'style' => PHPExcel_Style_Border::BORDER_THIN,
                  )
             )
         )
         );
            $objExcel->getActiveSheet()->getStyle('A' . $index.':'.$staticArrayData[$i].$index)->getFill()->applyFromArray(array(
               'type' => PHPExcel_Style_Fill::FILL_SOLID,
               'startcolor' => array(
                    'rgb' => 'f4d03f'
               )
           ));
            $objExcel->getActiveSheet()->getProtection()->setSheet(false); // Needs to be set to true in order to enable any worksheet protection!
            $objExcel->getActiveSheet()->protectCells('A1:'.$staticArray[$i], 'PHPExcel');
            $objExcel->getActiveSheet()->getStyle('A1:'.$staticArray[$i])->applyFromArray(
              array(
                'font'    => array(
                    'bold'      => true
                ),
                'alignment' => array(
                    'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                ),
                'borders' => array(
                    'allborders' => array(
                         'style' => PHPExcel_Style_Border::BORDER_THIN,
                     )
                )
            )
            );
            $objExcel->getActiveSheet()->getStyle('A1:'.$staticArray[$i])->getFill()->applyFromArray(array(
                'type' => PHPExcel_Style_Fill::FILL_SOLID,
                'startcolor' => array(
                     'rgb' => 'b5bee0'
                )
            ));
            $objExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(25);
            $objExcel->getActiveSheet()->getRowDimension($index)->setRowHeight(25);
            $objExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
            $objExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
            $objExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
            $objExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
            $objExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
            $objExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
            $objExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);


            $filename = $objEmployeeDataIdbi[0]['name']."_salary_".date('d_m_Y');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename=' . $filename . '.xls');
            header('Cache-Control: max-age=0');
            $objWriter = PHPExcel_IOFactory::createWriter($objExcel, 'Excel5');
            $objWriter->save('php://output');
        } else {
            return false;
        }
    }
    public function getCurrentMonthSalaryAll($empid)
    {
          $currentdate = date('d');
          if ($currentdate <= 25) {
              $month = date('m') - 1;
          } else {
              $month = date('m');
          }

          $year = date('yy');

          $objResult = $this->project_model->getCurrentMonthSalaryAll($empid,$month,$year);
          return $objResult;
    }
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while ($i < $digits_length) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
            } else {
                $str[] = null;
            }
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
    }

    public function viewProjectTotalSalary()
    {
        $objProjectTotal = $this->project_model->viewProjectTotalSalary();
    }

    public function assignLeavesProject()
    {
        $projectid = $this->input->post('id');
        $objLeavesMaster = $this->project_model->getAllLeavesType();
        $objProjectLeaves = $this->project_model->getProjectLeavesById($projectid);
        if (gettype($objProjectLeaves) == 'boolean') {
            $this->data["title"]="Project";
            $this->data["leavesmaster"] =  $objLeavesMaster;
            $this->data["projectid"] =  $projectid;
            $this->data['leaveslist'] = $objProjectLeaves;
            $this->load->view('frontend/project/add-leaves-to-project', $this->data);
        } else {
            $this->data["title"]="Project";
            $this->data["leavesmaster"] =  $objLeavesMaster;
            $this->data["projectid"] =  $projectid;
            $this->data['leaveslist'] = $objProjectLeaves;
            $this->load->view('frontend/project/add-leaves-to-project', $this->data);
        }
    }

    public function saveProjectLeaves()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('projectid');

            $objResult=$this->project_model->addleavesToProject();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Leaves Added successfully.");
                redirect("project/projectList");
            } else {
                $this->session->set_flashdata('errorMsg', "Leaves Already Added For This Project");
                redirect("project/projectList");
            }
        }
    }

    public function updateProjectLeaves()
    {
        if ($this->input->server('REQUEST_METHOD') == 'POST') {
            $id = $this->input->post('projectid');

            $objResult=$this->project_model->updateProjectLeaves();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Leaves Updated successfully.");
                redirect("project/projectList");
            } else {
                $this->session->set_flashdata('errorMsg', "Leaves Not Updated Due To Issue");
                redirect("project/projectList");
            }
        }
    }
}
