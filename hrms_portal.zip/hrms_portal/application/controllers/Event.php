<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Event extends TexBase
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Event_model', 'event_model');
        $this->data["title"] = "Home";
        $this->data["currentPage"] = "home";
        $this->load->library('curl');
    }

    public function getEventList()
    {
        $eventlist = $this->event_model->getEventList();
        $this->data["title"] = "Employee";
        $this->data["eventdata"] = $eventlist;
        //echo '<pre>';
        //print_r($eventlist);
        $this->templateFront("frontend/employee/event-list", $this->data);
    }

    public function index()
    {
        $this->data["title"] = "Employee";
        $this->templateFront("frontend/employee/add-event", $this->data);
    }

    public function addevent()
    {
       if(isset($_POST['submit'])){

            $this->event_model->addnewevent();
        }
        else
        {
            redirect('event/getEventList');
        }
    }
}
