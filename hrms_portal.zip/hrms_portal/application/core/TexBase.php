<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

use Doctrine\ORM\Tools\Pagination\Paginator;

class TexBase extends CI_Controller {

    function __construct($label = '') {
        parent::__construct();
        $this->em = $this->doctrine->em;
		$this->objQueryBuilder = $this->em->createQueryBuilder();
    }

    public function templateFront($template_name, $vars = array(), $return = FALSE)
    {
  		$this->load->view('front_header', $vars, $return);
      // if($return) {
      //   $this->load->view('main_slider', $vars, $return);
      // }
  		$this->load->view($template_name, $vars, $return);
  		$this->load->view('front_footer', $vars, $return);
    }

	function _encodeFilterConditions($arrFilterConditions)
	{
        return base64_encode(json_encode($arrFilterConditions));
    }

	function _decodeFilterConditions($encodedString, $index = null) {
		if (empty($index))
            return json_decode(base64_decode($encodedString), true);
        else
            return json_decode(base64_decode($encodedString), true)['page_no'];
    }
}
