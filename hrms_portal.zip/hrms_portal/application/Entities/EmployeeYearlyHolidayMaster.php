<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeYearlyHolidayMaster
 *
 * @ORM\Table(name="employee_yearly_holiday_master")
 * @ORM\Entity
 */
class EmployeeYearlyHolidayMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="date", nullable=false)
     */
    private $date;

    /**
     * @var string
     *
     * @ORM\Column(name="occasion", type="string", length=200, nullable=false)
     */
    private $occasion;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer", nullable=false)
     */
    private $status;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=150, nullable=false)
     */
    private $createdBy;

    /**
     * @var \ProjectMaster
     *
     * @ORM\ManyToOne(targetEntity="ProjectMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="project_id", referencedColumnName="id")
     * })
     */
    private $project;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return EmployeeYearlyHolidayMaster
     */
    public function setDate($date)
    {
        $this->date = $date;
    
        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set occasion
     *
     * @param string $occasion
     * @return EmployeeYearlyHolidayMaster
     */
    public function setOccasion($occasion)
    {
        $this->occasion = $occasion;
    
        return $this;
    }

    /**
     * Get occasion
     *
     * @return string 
     */
    public function getOccasion()
    {
        return $this->occasion;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return EmployeeYearlyHolidayMaster
     */
    public function setStatus($status)
    {
        $this->status = $status;
    
        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeYearlyHolidayMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     * @return EmployeeYearlyHolidayMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set project
     *
     * @param \ProjectMaster $project
     * @return EmployeeYearlyHolidayMaster
     */
    public function setProject(\ProjectMaster $project = null)
    {
        $this->project = $project;
    
        return $this;
    }

    /**
     * Get project
     *
     * @return \ProjectMaster 
     */
    public function getProject()
    {
        return $this->project;
    }
}