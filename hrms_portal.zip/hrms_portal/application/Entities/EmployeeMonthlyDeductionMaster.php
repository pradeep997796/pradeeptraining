<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeMonthlyDeductionMaster
 *
 * @ORM\Table(name="employee_monthly_deduction_master")
 * @ORM\Entity
 */
class EmployeeMonthlyDeductionMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="salary_date", type="date", nullable=false)
     */
    private $salaryDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="days", type="integer", nullable=false)
     */
    private $days;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=100, nullable=false)
     */
    private $createdBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="createddatetime", type="datetime", nullable=false)
     */
    private $createddatetime;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set salaryDate
     *
     * @param \DateTime $salaryDate
     * @return EmployeeMonthlyDeductionMaster
     */
    public function setSalaryDate($salaryDate)
    {
        $this->salaryDate = $salaryDate;
    
        return $this;
    }

    /**
     * Get salaryDate
     *
     * @return \DateTime 
     */
    public function getSalaryDate()
    {
        return $this->salaryDate;
    }

    /**
     * Set days
     *
     * @param integer $days
     * @return EmployeeMonthlyDeductionMaster
     */
    public function setDays($days)
    {
        $this->days = $days;
    
        return $this;
    }

    /**
     * Get days
     *
     * @return integer 
     */
    public function getDays()
    {
        return $this->days;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     * @return EmployeeMonthlyDeductionMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createddatetime
     *
     * @param \DateTime $createddatetime
     * @return EmployeeMonthlyDeductionMaster
     */
    public function setCreateddatetime($createddatetime)
    {
        $this->createddatetime = $createddatetime;
    
        return $this;
    }

    /**
     * Get createddatetime
     *
     * @return \DateTime 
     */
    public function getCreateddatetime()
    {
        return $this->createddatetime;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeMonthlyDeductionMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }
}