<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeLeaveBalanceMaster
 *
 * @ORM\Table(name="employee_leave_balance_master")
 * @ORM\Entity
 */
class EmployeeLeaveBalanceMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="year", type="integer", nullable=false)
     */
    private $year;

    /**
     * @var integer
     *
     * @ORM\Column(name="earned", type="integer", nullable=false)
     */
    private $earned;

    /**
     * @var integer
     *
     * @ORM\Column(name="available", type="integer", nullable=false)
     */
    private $available;

    /**
     * @var integer
     *
     * @ORM\Column(name="used", type="integer", nullable=false)
     */
    private $used;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_date", type="datetime", nullable=true)
     */
    private $updatedDate;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;

    /**
     * @var \LeaveCodeMaster
     *
     * @ORM\ManyToOne(targetEntity="LeaveCodeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="leave_code_id", referencedColumnName="id")
     * })
     */
    private $leaveCode;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set year
     *
     * @param integer $year
     * @return EmployeeLeaveBalanceMaster
     */
    public function setYear($year)
    {
        $this->year = $year;
    
        return $this;
    }

    /**
     * Get year
     *
     * @return integer 
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * Set earned
     *
     * @param integer $earned
     * @return EmployeeLeaveBalanceMaster
     */
    public function setEarned($earned)
    {
        $this->earned = $earned;
    
        return $this;
    }

    /**
     * Get earned
     *
     * @return integer 
     */
    public function getEarned()
    {
        return $this->earned;
    }

    /**
     * Set available
     *
     * @param integer $available
     * @return EmployeeLeaveBalanceMaster
     */
    public function setAvailable($available)
    {
        $this->available = $available;
    
        return $this;
    }

    /**
     * Get available
     *
     * @return integer 
     */
    public function getAvailable()
    {
        return $this->available;
    }

    /**
     * Set used
     *
     * @param integer $used
     * @return EmployeeLeaveBalanceMaster
     */
    public function setUsed($used)
    {
        $this->used = $used;
    
        return $this;
    }

    /**
     * Get used
     *
     * @return integer 
     */
    public function getUsed()
    {
        return $this->used;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeLeaveBalanceMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return EmployeeLeaveBalanceMaster
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;
    
        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime 
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeLeaveBalanceMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }

    /**
     * Set leaveCode
     *
     * @param \LeaveCodeMaster $leaveCode
     * @return EmployeeLeaveBalanceMaster
     */
    public function setLeaveCode(\LeaveCodeMaster $leaveCode = null)
    {
        $this->leaveCode = $leaveCode;
    
        return $this;
    }

    /**
     * Get leaveCode
     *
     * @return \LeaveCodeMaster 
     */
    public function getLeaveCode()
    {
        return $this->leaveCode;
    }
}