<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeMonthlySalaryMaster
 *
 * @ORM\Table(name="employee_monthly_salary_master")
 * @ORM\Entity
 */
class EmployeeMonthlySalaryMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="amount", type="integer", nullable=false)
     */
    private $amount;

    /**
     * @var integer
     *
     * @ORM\Column(name="total_earning", type="integer", nullable=false)
     */
    private $totalEarning;

    /**
     * @var integer
     *
     * @ORM\Column(name="total_deduction", type="integer", nullable=false)
     */
    private $totalDeduction;

    /**
     * @var integer
     *
     * @ORM\Column(name="employer_amount", type="integer", nullable=false)
     */
    private $employerAmount;

    /**
     * @var integer
     *
     * @ORM\Column(name="net_salary", type="integer", nullable=false)
     */
    private $netSalary;

    /**
     * @var integer
     *
     * @ORM\Column(name="salary_type", type="integer", nullable=false)
     */
    private $salaryType;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="salary_date", type="date", nullable=false)
     */
    private $salaryDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=255, nullable=false)
     */
    private $createdBy;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;

    /**
     * @var \SalaryStructureTypeMaster
     *
     * @ORM\ManyToOne(targetEntity="SalaryStructureTypeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="salary_type_id", referencedColumnName="id")
     * })
     */
    private $salaryType2;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set amount
     *
     * @param integer $amount
     * @return EmployeeMonthlySalaryMaster
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;
    
        return $this;
    }

    /**
     * Get amount
     *
     * @return integer 
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set totalEarning
     *
     * @param integer $totalEarning
     * @return EmployeeMonthlySalaryMaster
     */
    public function setTotalEarning($totalEarning)
    {
        $this->totalEarning = $totalEarning;
    
        return $this;
    }

    /**
     * Get totalEarning
     *
     * @return integer 
     */
    public function getTotalEarning()
    {
        return $this->totalEarning;
    }

    /**
     * Set totalDeduction
     *
     * @param integer $totalDeduction
     * @return EmployeeMonthlySalaryMaster
     */
    public function setTotalDeduction($totalDeduction)
    {
        $this->totalDeduction = $totalDeduction;
    
        return $this;
    }

    /**
     * Get totalDeduction
     *
     * @return integer 
     */
    public function getTotalDeduction()
    {
        return $this->totalDeduction;
    }

    /**
     * Set employerAmount
     *
     * @param integer $employerAmount
     * @return EmployeeMonthlySalaryMaster
     */
    public function setEmployerAmount($employerAmount)
    {
        $this->employerAmount = $employerAmount;
    
        return $this;
    }

    /**
     * Get employerAmount
     *
     * @return integer 
     */
    public function getEmployerAmount()
    {
        return $this->employerAmount;
    }

    /**
     * Set netSalary
     *
     * @param integer $netSalary
     * @return EmployeeMonthlySalaryMaster
     */
    public function setNetSalary($netSalary)
    {
        $this->netSalary = $netSalary;
    
        return $this;
    }

    /**
     * Get netSalary
     *
     * @return integer 
     */
    public function getNetSalary()
    {
        return $this->netSalary;
    }

    /**
     * Set salaryType
     *
     * @param integer $salaryType
     * @return EmployeeMonthlySalaryMaster
     */
    public function setSalaryType($salaryType)
    {
        $this->salaryType = $salaryType;
    
        return $this;
    }

    /**
     * Get salaryType
     *
     * @return integer 
     */
    public function getSalaryType()
    {
        return $this->salaryType;
    }

    /**
     * Set salaryDate
     *
     * @param \DateTime $salaryDate
     * @return EmployeeMonthlySalaryMaster
     */
    public function setSalaryDate($salaryDate)
    {
        $this->salaryDate = $salaryDate;
    
        return $this;
    }

    /**
     * Get salaryDate
     *
     * @return \DateTime 
     */
    public function getSalaryDate()
    {
        return $this->salaryDate;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeMonthlySalaryMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     * @return EmployeeMonthlySalaryMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeMonthlySalaryMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }

    /**
     * Set salaryType2
     *
     * @param \SalaryStructureTypeMaster $salaryType2
     * @return EmployeeMonthlySalaryMaster
     */
    public function setSalaryType2(\SalaryStructureTypeMaster $salaryType2 = null)
    {
        $this->salaryType2 = $salaryType2;
    
        return $this;
    }

    /**
     * Get salaryType2
     *
     * @return \SalaryStructureTypeMaster 
     */
    public function getSalaryType2()
    {
        return $this->salaryType2;
    }
}