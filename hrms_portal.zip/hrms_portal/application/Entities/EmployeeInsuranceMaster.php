<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeInsuranceMaster
 *
 * @ORM\Table(name="employee_insurance_master")
 * @ORM\Entity
 */
class EmployeeInsuranceMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="is_insured", type="integer", nullable=false)
     */
    private $isInsured;

    /**
     * @var string
     *
     * @ORM\Column(name="insurance_number", type="string", length=255, nullable=false)
     */
    private $insuranceNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="insurance_attachment", type="string", length=255, nullable=true)
     */
    private $insuranceAttachment;

    /**
     * @var integer
     *
     * @ORM\Column(name="lic_registered", type="integer", nullable=false)
     */
    private $licRegistered;

    /**
     * @var string
     *
     * @ORM\Column(name="lic_policy_number", type="string", length=255, nullable=false)
     */
    private $licPolicyNumber;

    /**
     * @var integer
     *
     * @ORM\Column(name="is_Esic", type="integer", nullable=false)
     */
    private $isEsic;

    /**
     * @var string
     *
     * @ORM\Column(name="tic_attachment", type="string", length=255, nullable=false)
     */
    private $ticAttachment;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=255, nullable=false)
     */
    private $createdBy;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set isInsured
     *
     * @param integer $isInsured
     * @return EmployeeInsuranceMaster
     */
    public function setIsInsured($isInsured)
    {
        $this->isInsured = $isInsured;
    
        return $this;
    }

    /**
     * Get isInsured
     *
     * @return integer 
     */
    public function getIsInsured()
    {
        return $this->isInsured;
    }

    /**
     * Set insuranceNumber
     *
     * @param string $insuranceNumber
     * @return EmployeeInsuranceMaster
     */
    public function setInsuranceNumber($insuranceNumber)
    {
        $this->insuranceNumber = $insuranceNumber;
    
        return $this;
    }

    /**
     * Get insuranceNumber
     *
     * @return string 
     */
    public function getInsuranceNumber()
    {
        return $this->insuranceNumber;
    }

    /**
     * Set insuranceAttachment
     *
     * @param string $insuranceAttachment
     * @return EmployeeInsuranceMaster
     */
    public function setInsuranceAttachment($insuranceAttachment)
    {
        $this->insuranceAttachment = $insuranceAttachment;
    
        return $this;
    }

    /**
     * Get insuranceAttachment
     *
     * @return string 
     */
    public function getInsuranceAttachment()
    {
        return $this->insuranceAttachment;
    }

    /**
     * Set licRegistered
     *
     * @param integer $licRegistered
     * @return EmployeeInsuranceMaster
     */
    public function setLicRegistered($licRegistered)
    {
        $this->licRegistered = $licRegistered;
    
        return $this;
    }

    /**
     * Get licRegistered
     *
     * @return integer 
     */
    public function getLicRegistered()
    {
        return $this->licRegistered;
    }

    /**
     * Set licPolicyNumber
     *
     * @param string $licPolicyNumber
     * @return EmployeeInsuranceMaster
     */
    public function setLicPolicyNumber($licPolicyNumber)
    {
        $this->licPolicyNumber = $licPolicyNumber;
    
        return $this;
    }

    /**
     * Get licPolicyNumber
     *
     * @return string 
     */
    public function getLicPolicyNumber()
    {
        return $this->licPolicyNumber;
    }

    /**
     * Set isEsic
     *
     * @param integer $isEsic
     * @return EmployeeInsuranceMaster
     */
    public function setIsEsic($isEsic)
    {
        $this->isEsic = $isEsic;
    
        return $this;
    }

    /**
     * Get isEsic
     *
     * @return integer 
     */
    public function getIsEsic()
    {
        return $this->isEsic;
    }

    /**
     * Set ticAttachment
     *
     * @param string $ticAttachment
     * @return EmployeeInsuranceMaster
     */
    public function setTicAttachment($ticAttachment)
    {
        $this->ticAttachment = $ticAttachment;
    
        return $this;
    }

    /**
     * Get ticAttachment
     *
     * @return string 
     */
    public function getTicAttachment()
    {
        return $this->ticAttachment;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeInsuranceMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     * @return EmployeeInsuranceMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeInsuranceMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }
}