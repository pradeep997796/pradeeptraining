<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeLeaveLogMaster
 *
 * @ORM\Table(name="employee_leave_log_master")
 * @ORM\Entity
 */
class EmployeeLeaveLogMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="leaves", type="integer", nullable=false)
     */
    private $leaves;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="salary_date", type="date", nullable=true)
     */
    private $salaryDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set leaves
     *
     * @param integer $leaves
     * @return EmployeeLeaveLogMaster
     */
    public function setLeaves($leaves)
    {
        $this->leaves = $leaves;
    
        return $this;
    }

    /**
     * Get leaves
     *
     * @return integer 
     */
    public function getLeaves()
    {
        return $this->leaves;
    }

    /**
     * Set salaryDate
     *
     * @param \DateTime $salaryDate
     * @return EmployeeLeaveLogMaster
     */
    public function setSalaryDate($salaryDate)
    {
        $this->salaryDate = $salaryDate;
    
        return $this;
    }

    /**
     * Get salaryDate
     *
     * @return \DateTime 
     */
    public function getSalaryDate()
    {
        return $this->salaryDate;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeLeaveLogMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeLeaveLogMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }
}