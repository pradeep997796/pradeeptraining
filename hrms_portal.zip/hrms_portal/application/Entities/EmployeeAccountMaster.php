<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeAccountMaster
 *
 * @ORM\Table(name="employee_account_master")
 * @ORM\Entity
 */
class EmployeeAccountMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_name", type="string", length=150, nullable=false)
     */
    private $bankName;

    /**
     * @var string
     *
     * @ORM\Column(name="branch", type="string", length=150, nullable=true)
     */
    private $branch;

    /**
     * @var string
     *
     * @ORM\Column(name="ifsc", type="string", length=50, nullable=true)
     */
    private $ifsc;

    /**
     * @var string
     *
     * @ORM\Column(name="account_number", type="string", length=200, nullable=false)
     */
    private $accountNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="account_type", type="string", length=50, nullable=true)
     */
    private $accountType;

    /**
     * @var integer
     *
     * @ORM\Column(name="is_idbi", type="integer", nullable=false)
     */
    private $isIdbi;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=100, nullable=false)
     */
    private $createdBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set bankName
     *
     * @param string $bankName
     * @return EmployeeAccountMaster
     */
    public function setBankName($bankName)
    {
        $this->bankName = $bankName;
    
        return $this;
    }

    /**
     * Get bankName
     *
     * @return string 
     */
    public function getBankName()
    {
        return $this->bankName;
    }

    /**
     * Set branch
     *
     * @param string $branch
     * @return EmployeeAccountMaster
     */
    public function setBranch($branch)
    {
        $this->branch = $branch;
    
        return $this;
    }

    /**
     * Get branch
     *
     * @return string 
     */
    public function getBranch()
    {
        return $this->branch;
    }

    /**
     * Set ifsc
     *
     * @param string $ifsc
     * @return EmployeeAccountMaster
     */
    public function setIfsc($ifsc)
    {
        $this->ifsc = $ifsc;
    
        return $this;
    }

    /**
     * Get ifsc
     *
     * @return string 
     */
    public function getIfsc()
    {
        return $this->ifsc;
    }

    /**
     * Set accountNumber
     *
     * @param string $accountNumber
     * @return EmployeeAccountMaster
     */
    public function setAccountNumber($accountNumber)
    {
        $this->accountNumber = $accountNumber;
    
        return $this;
    }

    /**
     * Get accountNumber
     *
     * @return string 
     */
    public function getAccountNumber()
    {
        return $this->accountNumber;
    }

    /**
     * Set accountType
     *
     * @param string $accountType
     * @return EmployeeAccountMaster
     */
    public function setAccountType($accountType)
    {
        $this->accountType = $accountType;
    
        return $this;
    }

    /**
     * Get accountType
     *
     * @return string 
     */
    public function getAccountType()
    {
        return $this->accountType;
    }

    /**
     * Set isIdbi
     *
     * @param integer $isIdbi
     * @return EmployeeAccountMaster
     */
    public function setIsIdbi($isIdbi)
    {
        $this->isIdbi = $isIdbi;
    
        return $this;
    }

    /**
     * Get isIdbi
     *
     * @return integer 
     */
    public function getIsIdbi()
    {
        return $this->isIdbi;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     * @return EmployeeAccountMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeAccountMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeAccountMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }
}