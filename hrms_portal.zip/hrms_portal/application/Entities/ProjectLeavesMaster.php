<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * ProjectLeavesMaster
 *
 * @ORM\Table(name="project_leaves_master")
 * @ORM\Entity
 */
class ProjectLeavesMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="leaves", type="integer", nullable=false)
     */
    private $leaves;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=false)
     */
    private $createdDate;

    /**
     * @var \ProjectMaster
     *
     * @ORM\ManyToOne(targetEntity="ProjectMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="project_id", referencedColumnName="id")
     * })
     */
    private $project;

    /**
     * @var \LeaveCodeMaster
     *
     * @ORM\ManyToOne(targetEntity="LeaveCodeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="leave_master_id", referencedColumnName="id")
     * })
     */
    private $leaveMaster;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set leaves
     *
     * @param integer $leaves
     * @return ProjectLeavesMaster
     */
    public function setLeaves($leaves)
    {
        $this->leaves = $leaves;
    
        return $this;
    }

    /**
     * Get leaves
     *
     * @return integer 
     */
    public function getLeaves()
    {
        return $this->leaves;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return ProjectLeavesMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set project
     *
     * @param \ProjectMaster $project
     * @return ProjectLeavesMaster
     */
    public function setProject(\ProjectMaster $project = null)
    {
        $this->project = $project;
    
        return $this;
    }

    /**
     * Get project
     *
     * @return \ProjectMaster 
     */
    public function getProject()
    {
        return $this->project;
    }

    /**
     * Set leaveMaster
     *
     * @param \LeaveCodeMaster $leaveMaster
     * @return ProjectLeavesMaster
     */
    public function setLeaveMaster(\LeaveCodeMaster $leaveMaster = null)
    {
        $this->leaveMaster = $leaveMaster;
    
        return $this;
    }

    /**
     * Get leaveMaster
     *
     * @return \LeaveCodeMaster 
     */
    public function getLeaveMaster()
    {
        return $this->leaveMaster;
    }
}