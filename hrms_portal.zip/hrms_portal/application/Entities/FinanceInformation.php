<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * FinanceInformation
 *
 * @ORM\Table(name="finance_information")
 * @ORM\Entity
 */
class FinanceInformation
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="uan_number", type="string", length=20, nullable=true)
     */
    private $uanNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="pf_number", type="string", length=20, nullable=true)
     */
    private $pfNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="esic_no", type="string", length=20, nullable=true)
     */
    private $esicNo;

    /**
     * @var float
     *
     * @ORM\Column(name="salary_in_hand", type="float", nullable=true)
     */
    private $salaryInHand;

    /**
     * @var float
     *
     * @ORM\Column(name="ctc", type="float", nullable=true)
     */
    private $ctc;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_details_attachment_type", type="string", length=20, nullable=true)
     */
    private $bankDetailsAttachmentType;

    /**
     * @var string
     *
     * @ORM\Column(name="bank_details_attachment", type="string", length=255, nullable=true)
     */
    private $bankDetailsAttachment;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="smallint", nullable=true)
     */
    private $status;

    /**
     * @var integer
     *
     * @ORM\Column(name="created_by", type="integer", nullable=true)
     */
    private $createdBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=true)
     */
    private $createdDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="updated_by", type="integer", nullable=true)
     */
    private $updatedBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_date", type="datetime", nullable=true)
     */
    private $updatedDate;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set uanNumber
     *
     * @param string $uanNumber
     * @return FinanceInformation
     */
    public function setUanNumber($uanNumber)
    {
        $this->uanNumber = $uanNumber;
    
        return $this;
    }

    /**
     * Get uanNumber
     *
     * @return string 
     */
    public function getUanNumber()
    {
        return $this->uanNumber;
    }

    /**
     * Set pfNumber
     *
     * @param string $pfNumber
     * @return FinanceInformation
     */
    public function setPfNumber($pfNumber)
    {
        $this->pfNumber = $pfNumber;
    
        return $this;
    }

    /**
     * Get pfNumber
     *
     * @return string 
     */
    public function getPfNumber()
    {
        return $this->pfNumber;
    }

    /**
     * Set esicNo
     *
     * @param string $esicNo
     * @return FinanceInformation
     */
    public function setEsicNo($esicNo)
    {
        $this->esicNo = $esicNo;
    
        return $this;
    }

    /**
     * Get esicNo
     *
     * @return string 
     */
    public function getEsicNo()
    {
        return $this->esicNo;
    }

    /**
     * Set salaryInHand
     *
     * @param float $salaryInHand
     * @return FinanceInformation
     */
    public function setSalaryInHand($salaryInHand)
    {
        $this->salaryInHand = $salaryInHand;
    
        return $this;
    }

    /**
     * Get salaryInHand
     *
     * @return float 
     */
    public function getSalaryInHand()
    {
        return $this->salaryInHand;
    }

    /**
     * Set ctc
     *
     * @param float $ctc
     * @return FinanceInformation
     */
    public function setCtc($ctc)
    {
        $this->ctc = $ctc;
    
        return $this;
    }

    /**
     * Get ctc
     *
     * @return float 
     */
    public function getCtc()
    {
        return $this->ctc;
    }

    /**
     * Set bankDetailsAttachmentType
     *
     * @param string $bankDetailsAttachmentType
     * @return FinanceInformation
     */
    public function setBankDetailsAttachmentType($bankDetailsAttachmentType)
    {
        $this->bankDetailsAttachmentType = $bankDetailsAttachmentType;
    
        return $this;
    }

    /**
     * Get bankDetailsAttachmentType
     *
     * @return string 
     */
    public function getBankDetailsAttachmentType()
    {
        return $this->bankDetailsAttachmentType;
    }

    /**
     * Set bankDetailsAttachment
     *
     * @param string $bankDetailsAttachment
     * @return FinanceInformation
     */
    public function setBankDetailsAttachment($bankDetailsAttachment)
    {
        $this->bankDetailsAttachment = $bankDetailsAttachment;
    
        return $this;
    }

    /**
     * Get bankDetailsAttachment
     *
     * @return string 
     */
    public function getBankDetailsAttachment()
    {
        return $this->bankDetailsAttachment;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return FinanceInformation
     */
    public function setStatus($status)
    {
        $this->status = $status;
    
        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set createdBy
     *
     * @param integer $createdBy
     * @return FinanceInformation
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return integer 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return FinanceInformation
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set updatedBy
     *
     * @param integer $updatedBy
     * @return FinanceInformation
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;
    
        return $this;
    }

    /**
     * Get updatedBy
     *
     * @return integer 
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return FinanceInformation
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;
    
        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime 
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return FinanceInformation
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }
}