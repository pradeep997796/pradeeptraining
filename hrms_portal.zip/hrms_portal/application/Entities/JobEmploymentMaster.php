<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * JobEmploymentMaster
 *
 * @ORM\Table(name="job_employment_master")
 * @ORM\Entity
 */
class JobEmploymentMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="employee_status", type="string", length=50, nullable=true)
     */
    private $employeeStatus;

    /**
     * @var string
     *
     * @ORM\Column(name="company_name", type="string", length=200, nullable=true)
     */
    private $companyName;

    /**
     * @var string
     *
     * @ORM\Column(name="location", type="string", length=100, nullable=true)
     */
    private $location;

    /**
     * @var string
     *
     * @ORM\Column(name="department_id", type="string", length=200, nullable=true)
     */
    private $departmentId;

    /**
     * @var string
     *
     * @ORM\Column(name="payroll_company", type="string", length=200, nullable=true)
     */
    private $payrollCompany;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="role_entry_date", type="date", nullable=true)
     */
    private $roleEntryDate;

    /**
     * @var string
     *
     * @ORM\Column(name="designation", type="string", length=100, nullable=true)
     */
    private $designation;

    /**
     * @var string
     *
     * @ORM\Column(name="employment_type", type="string", length=50, nullable=true)
     */
    private $employmentType;

    /**
     * @var string
     *
     * @ORM\Column(name="employment_status", type="string", length=20, nullable=true)
     */
    private $employmentStatus;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=true)
     */
    private $createdDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="created_by", type="integer", nullable=true)
     */
    private $createdBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_date", type="datetime", nullable=true)
     */
    private $updatedDate;

    /**
     * @var integer
     *
     * @ORM\Column(name="updated_by", type="integer", nullable=true)
     */
    private $updatedBy;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;

    /**
     * @var \ProjectMaster
     *
     * @ORM\ManyToOne(targetEntity="ProjectMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="project_id", referencedColumnName="id")
     * })
     */
    private $project;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set employeeStatus
     *
     * @param string $employeeStatus
     * @return JobEmploymentMaster
     */
    public function setEmployeeStatus($employeeStatus)
    {
        $this->employeeStatus = $employeeStatus;
    
        return $this;
    }

    /**
     * Get employeeStatus
     *
     * @return string 
     */
    public function getEmployeeStatus()
    {
        return $this->employeeStatus;
    }

    /**
     * Set companyName
     *
     * @param string $companyName
     * @return JobEmploymentMaster
     */
    public function setCompanyName($companyName)
    {
        $this->companyName = $companyName;
    
        return $this;
    }

    /**
     * Get companyName
     *
     * @return string 
     */
    public function getCompanyName()
    {
        return $this->companyName;
    }

    /**
     * Set location
     *
     * @param string $location
     * @return JobEmploymentMaster
     */
    public function setLocation($location)
    {
        $this->location = $location;
    
        return $this;
    }

    /**
     * Get location
     *
     * @return string 
     */
    public function getLocation()
    {
        return $this->location;
    }

    /**
     * Set departmentId
     *
     * @param string $departmentId
     * @return JobEmploymentMaster
     */
    public function setDepartmentId($departmentId)
    {
        $this->departmentId = $departmentId;
    
        return $this;
    }

    /**
     * Get departmentId
     *
     * @return string 
     */
    public function getDepartmentId()
    {
        return $this->departmentId;
    }

    /**
     * Set payrollCompany
     *
     * @param string $payrollCompany
     * @return JobEmploymentMaster
     */
    public function setPayrollCompany($payrollCompany)
    {
        $this->payrollCompany = $payrollCompany;
    
        return $this;
    }

    /**
     * Get payrollCompany
     *
     * @return string 
     */
    public function getPayrollCompany()
    {
        return $this->payrollCompany;
    }

    /**
     * Set roleEntryDate
     *
     * @param \DateTime $roleEntryDate
     * @return JobEmploymentMaster
     */
    public function setRoleEntryDate($roleEntryDate)
    {
        $this->roleEntryDate = $roleEntryDate;
    
        return $this;
    }

    /**
     * Get roleEntryDate
     *
     * @return \DateTime 
     */
    public function getRoleEntryDate()
    {
        return $this->roleEntryDate;
    }

    /**
     * Set designation
     *
     * @param string $designation
     * @return JobEmploymentMaster
     */
    public function setDesignation($designation)
    {
        $this->designation = $designation;
    
        return $this;
    }

    /**
     * Get designation
     *
     * @return string 
     */
    public function getDesignation()
    {
        return $this->designation;
    }

    /**
     * Set employmentType
     *
     * @param string $employmentType
     * @return JobEmploymentMaster
     */
    public function setEmploymentType($employmentType)
    {
        $this->employmentType = $employmentType;
    
        return $this;
    }

    /**
     * Get employmentType
     *
     * @return string 
     */
    public function getEmploymentType()
    {
        return $this->employmentType;
    }

    /**
     * Set employmentStatus
     *
     * @param string $employmentStatus
     * @return JobEmploymentMaster
     */
    public function setEmploymentStatus($employmentStatus)
    {
        $this->employmentStatus = $employmentStatus;
    
        return $this;
    }

    /**
     * Get employmentStatus
     *
     * @return string 
     */
    public function getEmploymentStatus()
    {
        return $this->employmentStatus;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return JobEmploymentMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set createdBy
     *
     * @param integer $createdBy
     * @return JobEmploymentMaster
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;
    
        return $this;
    }

    /**
     * Get createdBy
     *
     * @return integer 
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return JobEmploymentMaster
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;
    
        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime 
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }

    /**
     * Set updatedBy
     *
     * @param integer $updatedBy
     * @return JobEmploymentMaster
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;
    
        return $this;
    }

    /**
     * Get updatedBy
     *
     * @return integer 
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return JobEmploymentMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }

    /**
     * Set project
     *
     * @param \ProjectMaster $project
     * @return JobEmploymentMaster
     */
    public function setProject(\ProjectMaster $project = null)
    {
        $this->project = $project;
    
        return $this;
    }

    /**
     * Get project
     *
     * @return \ProjectMaster 
     */
    public function getProject()
    {
        return $this->project;
    }
}