<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeSalaryMaster
 *
 * @ORM\Table(name="employee_salary_master")
 * @ORM\Entity
 */
class EmployeeSalaryMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var integer
     *
     * @ORM\Column(name="salary_type", type="integer", nullable=false)
     */
    private $salaryType;

    /**
     * @var float
     *
     * @ORM\Column(name="amount", type="float", nullable=false)
     */
    private $amount;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="createddate", type="datetime", nullable=false)
     */
    private $createddate;

    /**
     * @var string
     *
     * @ORM\Column(name="createdby", type="string", length=255, nullable=false)
     */
    private $createdby;

    /**
     * @var \EmployeeMaster
     *
     * @ORM\ManyToOne(targetEntity="EmployeeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="emp_id", referencedColumnName="id")
     * })
     */
    private $emp;

    /**
     * @var \SalaryStructureTypeMaster
     *
     * @ORM\ManyToOne(targetEntity="SalaryStructureTypeMaster")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="salary_id", referencedColumnName="id")
     * })
     */
    private $salary;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set salaryType
     *
     * @param integer $salaryType
     * @return EmployeeSalaryMaster
     */
    public function setSalaryType($salaryType)
    {
        $this->salaryType = $salaryType;
    
        return $this;
    }

    /**
     * Get salaryType
     *
     * @return integer 
     */
    public function getSalaryType()
    {
        return $this->salaryType;
    }

    /**
     * Set amount
     *
     * @param float $amount
     * @return EmployeeSalaryMaster
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;
    
        return $this;
    }

    /**
     * Get amount
     *
     * @return float 
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set createddate
     *
     * @param \DateTime $createddate
     * @return EmployeeSalaryMaster
     */
    public function setCreateddate($createddate)
    {
        $this->createddate = $createddate;
    
        return $this;
    }

    /**
     * Get createddate
     *
     * @return \DateTime 
     */
    public function getCreateddate()
    {
        return $this->createddate;
    }

    /**
     * Set createdby
     *
     * @param string $createdby
     * @return EmployeeSalaryMaster
     */
    public function setCreatedby($createdby)
    {
        $this->createdby = $createdby;
    
        return $this;
    }

    /**
     * Get createdby
     *
     * @return string 
     */
    public function getCreatedby()
    {
        return $this->createdby;
    }

    /**
     * Set emp
     *
     * @param \EmployeeMaster $emp
     * @return EmployeeSalaryMaster
     */
    public function setEmp(\EmployeeMaster $emp = null)
    {
        $this->emp = $emp;
    
        return $this;
    }

    /**
     * Get emp
     *
     * @return \EmployeeMaster 
     */
    public function getEmp()
    {
        return $this->emp;
    }

    /**
     * Set salary
     *
     * @param \SalaryStructureTypeMaster $salary
     * @return EmployeeSalaryMaster
     */
    public function setSalary(\SalaryStructureTypeMaster $salary = null)
    {
        $this->salary = $salary;
    
        return $this;
    }

    /**
     * Get salary
     *
     * @return \SalaryStructureTypeMaster 
     */
    public function getSalary()
    {
        return $this->salary;
    }
}