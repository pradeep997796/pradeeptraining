<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * SalaryStructureTypeMaster
 *
 * @ORM\Table(name="salary_structure_type_master")
 * @ORM\Entity
 */
class SalaryStructureTypeMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, nullable=false)
     */
    private $name;

    /**
     * @var integer
     *
     * @ORM\Column(name="salary_type", type="integer", nullable=false)
     */
    private $salaryType;

    /**
     * @var float
     *
     * @ORM\Column(name="percentage", type="float", nullable=false)
     */
    private $percentage;

    /**
     * @var integer
     *
     * @ORM\Column(name="is_deductable", type="integer", nullable=false)
     */
    private $isDeductable;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="integer", nullable=false)
     */
    private $status;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return SalaryStructureTypeMaster
     */
    public function setName($name)
    {
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set salaryType
     *
     * @param integer $salaryType
     * @return SalaryStructureTypeMaster
     */
    public function setSalaryType($salaryType)
    {
        $this->salaryType = $salaryType;
    
        return $this;
    }

    /**
     * Get salaryType
     *
     * @return integer 
     */
    public function getSalaryType()
    {
        return $this->salaryType;
    }

    /**
     * Set percentage
     *
     * @param float $percentage
     * @return SalaryStructureTypeMaster
     */
    public function setPercentage($percentage)
    {
        $this->percentage = $percentage;
    
        return $this;
    }

    /**
     * Get percentage
     *
     * @return float 
     */
    public function getPercentage()
    {
        return $this->percentage;
    }

    /**
     * Set isDeductable
     *
     * @param integer $isDeductable
     * @return SalaryStructureTypeMaster
     */
    public function setIsDeductable($isDeductable)
    {
        $this->isDeductable = $isDeductable;
    
        return $this;
    }

    /**
     * Get isDeductable
     *
     * @return integer 
     */
    public function getIsDeductable()
    {
        return $this->isDeductable;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return SalaryStructureTypeMaster
     */
    public function setStatus($status)
    {
        $this->status = $status;
    
        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }
}