<?php



use Doctrine\ORM\Mapping as ORM;

/**
 * EmployeeMaster
 *
 * @ORM\Table(name="employee_master")
 * @ORM\Entity
 */
class EmployeeMaster
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=10, nullable=true)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="first_name", type="string", length=100, nullable=false)
     */
    private $firstName;

    /**
     * @var string
     *
     * @ORM\Column(name="middle_name", type="string", length=100, nullable=true)
     */
    private $middleName;

    /**
     * @var string
     *
     * @ORM\Column(name="last_name", type="string", length=100, nullable=false)
     */
    private $lastName;

    /**
     * @var string
     *
     * @ORM\Column(name="username", type="string", length=200, nullable=false)
     */
    private $username;

    /**
     * @var string
     *
     * @ORM\Column(name="employee_id", type="string", length=20, nullable=true)
     */
    private $employeeId;

    /**
     * @var string
     *
     * @ORM\Column(name="password", type="string", length=200, nullable=false)
     */
    private $password;

    /**
     * @var string
     *
     * @ORM\Column(name="business_email", type="string", length=100, nullable=true)
     */
    private $businessEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="personal_email", type="string", length=100, nullable=true)
     */
    private $personalEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="business_contact_number", type="string", length=10, nullable=true)
     */
    private $businessContactNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="personal_contact_number", type="string", length=10, nullable=true)
     */
    private $personalContactNumber;

    /**
     * @var string
     *
     * @ORM\Column(name="alternate_contact_number", type="string", length=10, nullable=true)
     */
    private $alternateContactNumber;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_of_birth", type="date", nullable=true)
     */
    private $dateOfBirth;

    /**
     * @var string
     *
     * @ORM\Column(name="place_of_birth", type="string", length=100, nullable=true)
     */
    private $placeOfBirth;

    /**
     * @var string
     *
     * @ORM\Column(name="blood_group", type="string", length=5, nullable=true)
     */
    private $bloodGroup;

    /**
     * @var string
     *
     * @ORM\Column(name="gender", type="string", length=10, nullable=true)
     */
    private $gender;

    /**
     * @var string
     *
     * @ORM\Column(name="profile_image", type="string", length=255, nullable=true)
     */
    private $profileImage;

    /**
     * @var string
     *
     * @ORM\Column(name="marital_status", type="string", length=20, nullable=true)
     */
    private $maritalStatus;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="marriage_date", type="date", nullable=true)
     */
    private $marriageDate;

    /**
     * @var string
     *
     * @ORM\Column(name="nationality", type="string", length=10, nullable=true)
     */
    private $nationality;

    /**
     * @var string
     *
     * @ORM\Column(name="mother_tongue", type="string", length=50, nullable=true)
     */
    private $motherTongue;

    /**
     * @var string
     *
     * @ORM\Column(name="religion", type="string", length=20, nullable=true)
     */
    private $religion;

    /**
     * @var integer
     *
     * @ORM\Column(name="status", type="smallint", nullable=false)
     */
    private $status;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_date", type="datetime", nullable=true)
     */
    private $createdDate;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_date", type="datetime", nullable=true)
     */
    private $updatedDate;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return EmployeeMaster
     */
    public function setTitle($title)
    {
        $this->title = $title;
    
        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set firstName
     *
     * @param string $firstName
     * @return EmployeeMaster
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    
        return $this;
    }

    /**
     * Get firstName
     *
     * @return string 
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * Set middleName
     *
     * @param string $middleName
     * @return EmployeeMaster
     */
    public function setMiddleName($middleName)
    {
        $this->middleName = $middleName;
    
        return $this;
    }

    /**
     * Get middleName
     *
     * @return string 
     */
    public function getMiddleName()
    {
        return $this->middleName;
    }

    /**
     * Set lastName
     *
     * @param string $lastName
     * @return EmployeeMaster
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;
    
        return $this;
    }

    /**
     * Get lastName
     *
     * @return string 
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * Set username
     *
     * @param string $username
     * @return EmployeeMaster
     */
    public function setUsername($username)
    {
        $this->username = $username;
    
        return $this;
    }

    /**
     * Get username
     *
     * @return string 
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set employeeId
     *
     * @param string $employeeId
     * @return EmployeeMaster
     */
    public function setEmployeeId($employeeId)
    {
        $this->employeeId = $employeeId;
    
        return $this;
    }

    /**
     * Get employeeId
     *
     * @return string 
     */
    public function getEmployeeId()
    {
        return $this->employeeId;
    }

    /**
     * Set password
     *
     * @param string $password
     * @return EmployeeMaster
     */
    public function setPassword($password)
    {
        $this->password = $password;
    
        return $this;
    }

    /**
     * Get password
     *
     * @return string 
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set businessEmail
     *
     * @param string $businessEmail
     * @return EmployeeMaster
     */
    public function setBusinessEmail($businessEmail)
    {
        $this->businessEmail = $businessEmail;
    
        return $this;
    }

    /**
     * Get businessEmail
     *
     * @return string 
     */
    public function getBusinessEmail()
    {
        return $this->businessEmail;
    }

    /**
     * Set personalEmail
     *
     * @param string $personalEmail
     * @return EmployeeMaster
     */
    public function setPersonalEmail($personalEmail)
    {
        $this->personalEmail = $personalEmail;
    
        return $this;
    }

    /**
     * Get personalEmail
     *
     * @return string 
     */
    public function getPersonalEmail()
    {
        return $this->personalEmail;
    }

    /**
     * Set businessContactNumber
     *
     * @param string $businessContactNumber
     * @return EmployeeMaster
     */
    public function setBusinessContactNumber($businessContactNumber)
    {
        $this->businessContactNumber = $businessContactNumber;
    
        return $this;
    }

    /**
     * Get businessContactNumber
     *
     * @return string 
     */
    public function getBusinessContactNumber()
    {
        return $this->businessContactNumber;
    }

    /**
     * Set personalContactNumber
     *
     * @param string $personalContactNumber
     * @return EmployeeMaster
     */
    public function setPersonalContactNumber($personalContactNumber)
    {
        $this->personalContactNumber = $personalContactNumber;
    
        return $this;
    }

    /**
     * Get personalContactNumber
     *
     * @return string 
     */
    public function getPersonalContactNumber()
    {
        return $this->personalContactNumber;
    }

    /**
     * Set alternateContactNumber
     *
     * @param string $alternateContactNumber
     * @return EmployeeMaster
     */
    public function setAlternateContactNumber($alternateContactNumber)
    {
        $this->alternateContactNumber = $alternateContactNumber;
    
        return $this;
    }

    /**
     * Get alternateContactNumber
     *
     * @return string 
     */
    public function getAlternateContactNumber()
    {
        return $this->alternateContactNumber;
    }

    /**
     * Set dateOfBirth
     *
     * @param \DateTime $dateOfBirth
     * @return EmployeeMaster
     */
    public function setDateOfBirth($dateOfBirth)
    {
        $this->dateOfBirth = $dateOfBirth;
    
        return $this;
    }

    /**
     * Get dateOfBirth
     *
     * @return \DateTime 
     */
    public function getDateOfBirth()
    {
        return $this->dateOfBirth;
    }

    /**
     * Set placeOfBirth
     *
     * @param string $placeOfBirth
     * @return EmployeeMaster
     */
    public function setPlaceOfBirth($placeOfBirth)
    {
        $this->placeOfBirth = $placeOfBirth;
    
        return $this;
    }

    /**
     * Get placeOfBirth
     *
     * @return string 
     */
    public function getPlaceOfBirth()
    {
        return $this->placeOfBirth;
    }

    /**
     * Set bloodGroup
     *
     * @param string $bloodGroup
     * @return EmployeeMaster
     */
    public function setBloodGroup($bloodGroup)
    {
        $this->bloodGroup = $bloodGroup;
    
        return $this;
    }

    /**
     * Get bloodGroup
     *
     * @return string 
     */
    public function getBloodGroup()
    {
        return $this->bloodGroup;
    }

    /**
     * Set gender
     *
     * @param string $gender
     * @return EmployeeMaster
     */
    public function setGender($gender)
    {
        $this->gender = $gender;
    
        return $this;
    }

    /**
     * Get gender
     *
     * @return string 
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set profileImage
     *
     * @param string $profileImage
     * @return EmployeeMaster
     */
    public function setProfileImage($profileImage)
    {
        $this->profileImage = $profileImage;
    
        return $this;
    }

    /**
     * Get profileImage
     *
     * @return string 
     */
    public function getProfileImage()
    {
        return $this->profileImage;
    }

    /**
     * Set maritalStatus
     *
     * @param string $maritalStatus
     * @return EmployeeMaster
     */
    public function setMaritalStatus($maritalStatus)
    {
        $this->maritalStatus = $maritalStatus;
    
        return $this;
    }

    /**
     * Get maritalStatus
     *
     * @return string 
     */
    public function getMaritalStatus()
    {
        return $this->maritalStatus;
    }

    /**
     * Set marriageDate
     *
     * @param \DateTime $marriageDate
     * @return EmployeeMaster
     */
    public function setMarriageDate($marriageDate)
    {
        $this->marriageDate = $marriageDate;
    
        return $this;
    }

    /**
     * Get marriageDate
     *
     * @return \DateTime 
     */
    public function getMarriageDate()
    {
        return $this->marriageDate;
    }

    /**
     * Set nationality
     *
     * @param string $nationality
     * @return EmployeeMaster
     */
    public function setNationality($nationality)
    {
        $this->nationality = $nationality;
    
        return $this;
    }

    /**
     * Get nationality
     *
     * @return string 
     */
    public function getNationality()
    {
        return $this->nationality;
    }

    /**
     * Set motherTongue
     *
     * @param string $motherTongue
     * @return EmployeeMaster
     */
    public function setMotherTongue($motherTongue)
    {
        $this->motherTongue = $motherTongue;
    
        return $this;
    }

    /**
     * Get motherTongue
     *
     * @return string 
     */
    public function getMotherTongue()
    {
        return $this->motherTongue;
    }

    /**
     * Set religion
     *
     * @param string $religion
     * @return EmployeeMaster
     */
    public function setReligion($religion)
    {
        $this->religion = $religion;
    
        return $this;
    }

    /**
     * Get religion
     *
     * @return string 
     */
    public function getReligion()
    {
        return $this->religion;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return EmployeeMaster
     */
    public function setStatus($status)
    {
        $this->status = $status;
    
        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set createdDate
     *
     * @param \DateTime $createdDate
     * @return EmployeeMaster
     */
    public function setCreatedDate($createdDate)
    {
        $this->createdDate = $createdDate;
    
        return $this;
    }

    /**
     * Get createdDate
     *
     * @return \DateTime 
     */
    public function getCreatedDate()
    {
        return $this->createdDate;
    }

    /**
     * Set updatedDate
     *
     * @param \DateTime $updatedDate
     * @return EmployeeMaster
     */
    public function setUpdatedDate($updatedDate)
    {
        $this->updatedDate = $updatedDate;
    
        return $this;
    }

    /**
     * Get updatedDate
     *
     * @return \DateTime 
     */
    public function getUpdatedDate()
    {
        return $this->updatedDate;
    }
}