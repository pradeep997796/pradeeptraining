<?php
//error_reporting(0);
defined('BASEPATH') or exit('No direct script access allowed');

class Hr extends TexBase
{
    public function __construct()
    {
        parent :: __construct();
        $this->load->model('Employee_model', 'employee_model');
        $this->load->model('Project_model', 'project_model');
        $this->load->model('Hr_model', 'hr_model');
        $this->data["title"]="Home";
        $this->data["currentPage"]="home";
        $this->load->library('curl');
    }

    public function index()
    {
        redirect("employee/employeeList");
    }

    public function calculateSalary()
    {
        if (isset($_POST['submit'])) {
            if (isset($_POST['earningsalaryId'])) {
                $objResult = $this->hr_model->saveMonthlySalaryEdit();
            } else {
                $objResult = $this->hr_model->saveMonthlySalary();
            }

            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Employee Salary Saved Successfully.");
                redirect("hr/calculateSalary");
            } else {
                $this->session->set_flashdata('errorMsg', "Employee Salary Not Saved, Please Try Again.");
                redirect("hr/calculateSalary");
            }
        } else {
            $this->data["title"]="Salary Calculations";
            $this->data["projectList"] = $this->project_model->getAllProjects();
            $this->templateFront("frontend/hr/calculate-employee-salary", $this->data);
        }
    }

    public function viewEmployeeSalary()
    {
        $this->data["title"]="View Monthly Salary";
        $this->data["projectList"] = $this->project_model->getAllProjects();
        $this->templateFront("frontend/hr/view-employee-monthly-salary", $this->data);
    }

    public function getProjectEmployee()
    {
        $projectid = $this->input->post('projectid');
        $employeeList = $this->hr_model->getProjectEmployee($projectid);
        $this->data["employeeList"] = $employeeList;
        if ($this->input->post('option') == 'save') {
            $this->load->view('frontend/hr/employeeList-dropdown', $this->data);
        } else {
            $this->load->view('frontend/hr/employeeList-dropdown-view', $this->data);
        }
    }

    public function getEmployeeMonthlySalary()
    {
        $empid = $this->input->post('empid');
        $month = $this->input->post('month');
        $year = $this->input->post('year');

        $objSalaryData = $this->hr_model->getSelectedMonthSalary($empid, $month, $year);
        if (gettype($objSalaryData) === 'boolean') {
            echo 0;
        } else {
            $employeeSalary = $this->hr_model->getEmployeeSalaryDetails($empid);
            $objEarning = $objSalaryData['earningInfo'];
            $objDeduction = $objSalaryData['deductionInfo'];
            $objEmployer = $objSalaryData['employerInfo'];
            //echo "<pre>"; print_r($objEarning);die;
            $this->data["employeeid"] = $empid;
            $this->data["earningInfo"] = $objEarning;
            $this->data["deductionInfo"] = $objDeduction;
            $this->data["employerInfo"] = $objEmployer;
            $this->data["employeeSalary"] = $employeeSalary;
            $this->data["month"] = $month;
            $this->data["year"] = $year;
            $this->load->view('frontend/hr/view-employee-salary', $this->data);
        }
    }
    public function downloadSalaryPdf()
    {
        $empid = $this->uri->segment(3);
        $month = $this->uri->segment(4);
        $year = $this->uri->segment(5);
        $monthName = date('F', mktime(0, 0, 0, $month, 10));

        $totaldays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $objSalaryData = $this->hr_model->getSelectedMonthSalary($empid, $month, $year);
        $employeeSalary = $this->hr_model->getEmployeeSalaryDetails($empid);
        $empAccountData = $this->hr_model->getEmployerAccountInfo($empid);
        $empProjectData = $this->employee_model->getJobInfo($empid);
        $objEarningActual = $this->employee_model->getEarningInfo($empid);
        $objDeductionActual = $this->employee_model->getDeductionInfo($empid);
        $objfinanceInfo = $this->employee_model->getEmployeeFinanceInfo($empid);
        //echo $objfinanceInfo[0]->getEsicNo();die;
        $objEarning = $objSalaryData['earningInfo'];
        $objDeduction = $objSalaryData['deductionInfo'];
        $objEmployer = $objSalaryData['employerInfo'];
        $objLeaves = $objSalaryData['leavesInfo'];
        if (gettype($objLeaves)=== 'boolean') {
            $presentdays = $totaldays;
        } else {
            $presentdays = $totaldays - $objLeaves[0]->getLeaves();
        }

        $this->data["earningInfo"] = $objEarning;
        $this->data["deductionInfo"] = $objDeduction;
        $this->data["employerInfo"] = $objEmployer;
        $this->data["employeeSalary"] = $employeeSalary;
        $this->data['accountInfo'] = $empAccountData;
        $this->data['jobInfo'] = $empProjectData[0];
        $this->data['earningInfoActual'] = $objEarningActual;
        $this->data['deductionInfoActual'] = $objDeductionActual;
        $this->data['presentdays'] = $presentdays;
        $this->data['totaldays'] = $totaldays;
        $this->data['financeInfo'] = $objfinanceInfo;
        $this->data['month'] = $monthName;
        $this->data['year'] = $year;

        $this->load->library('pdf');
        $html = $this->load->view('pdf/template', $this->data, true);
        //echo $html; die;
        $name = $employeeSalary[0]->getEmp()->getFirstName()." ".$employeeSalary[0]->getEmp()->getMiddleName()." ".$employeeSalary[0]->getEmp()->getLastName();
        $filename = $name.'_'.$empid."_".$month."_".$year;
        $dompdf = $this->pdf->getDompdfObject();
        $options = $dompdf->getOptions();
        $options->set(array('isRemoteEnabled' => true));
        $dompdf->setOptions($options);
        $dompdf->loadHtml($html);
        $dompdf->render();
        $dompdf->stream($filename.'.pdf');
    }


    public function getSalaryEmployee()
    {
        $empid = $this->input->post('empid');
        $month = date('m')-1;
        $year = date('yy');
        $totaldays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        //Checking If Salary Of this Month Exists
        $objSalaryData = $this->hr_model->getCurrentMonthSalary($empid);
        if (gettype($objSalaryData) === 'boolean') {
            $employeeSalary = $this->hr_model->getEmployeeSalaryDetails($empid);
            if (gettype($employeeSalary)=== 'boolean') {
                echo 0;
            } else {
                $this->data["employeeSalary"] = $employeeSalary;
                $this->data["totaldays"] = $totaldays;
                $this->load->view('frontend/hr/employee-salary-structure', $this->data);
            }
        } else {
            $employeeSalary = $this->hr_model->getEmployeeSalaryDetails($empid);
            $objLeaves = $objSalaryData['leavesInfo'];
            if (gettype($objLeaves)=== 'boolean') {
                $presentdays = $totaldays;
                $leaveid = 0 ;
                $prevousleaves = 0;
            } else {
                $presentdays = $totaldays - $objLeaves[0]->getLeaves();
                $leaveid = $objLeaves[0]->getId();
                $prevousleaves = $objLeaves[0]->getLeaves();
            }

            $this->data["employeeSalary"] = $employeeSalary;
            $this->data["presentdays"] = $presentdays;
            $this->data["totaldays"] = $totaldays;
            $this->data["leaveid"] = $leaveid;
            $this->data["previousLeaves"] = $prevousleaves;

            $this->load->view('frontend/hr/employee-salary-structure-edit', $this->data);

            // $employeeSalary = $this->hr_model->getEmployeeSalaryDetails($empid);
            // $leaves = $this->hr_model->getLeavesTaken($empid);
            // $objEarning = $objSalaryData['earningInfo'];
            // $objDeduction = $objSalaryData['deductionInfo'];
            // $objEmployer = $objSalaryData['employerInfo'];
            // $objLeaves = $objSalaryData['leavesInfo'];
            //
            // $this->data["employeeSalary"] = $employeeSalary;
            // $this->data["earningInfo"] = $objEarning;
            // $this->data["deductionInfo"] = $objDeduction;
            // $this->data["employerInfo"] = $objEmployer;
            // $this->data["leavesInfo"] = $objLeaves;
            // $this->load->view('frontend/hr/view-employee-salary', $this->data);
        }
    }

    public function getCalculatedSalary()
    {
        $empid = $this->input->post('empid');
        $totaldays = $this->input->post('totaldays');
        $presentdays = $this->input->post('presentdays');

        $leaves = $totaldays - $presentdays;
        $available = $this->getemployeeLeaveBalance($empid);
        $newBalance = $available - $leaves;
        if ($newBalance < 0) {
            // this means availabe is less than to be taken
            $deductionDays = $newBalance * -1;
        } else {
            $deductionDays = 0 ;
        }
        //echo $deductionDays;die;

        $objEarning = $this->employee_model->getEarningInfo($empid);
        $objDeduction = $this->employee_model->getDeductionInfo($empid);
        $objEmployer = $this->employee_model->getEmployerContributionInfo($empid);

        $this->data["earningInfo"] = $objEarning;
        $this->data["deductionInfo"] = $objDeduction;
        $this->data["employerInfo"] = $objEmployer;
        $this->data["presentdays"] = $presentdays;
        $this->data["totaldays"] = $totaldays;
        $this->data["employeeid"] = $empid;
        $this->data["deductiondays"] = $deductionDays;
        $this->load->view('frontend/hr/employee-salary-adjust', $this->data);
    }

    public function getGeneratedSalaryEdit()
    {
        $empid = $this->input->post('empid');
        $totaldays = $this->input->post('totaldays');
        $presentdays = $this->input->post('presentdays');

        $leaves = $totaldays - $presentdays;
        $available = $this->getemployeeLeaveBalance($empid);
        $newBalance = $available - $leaves;
        if ($newBalance < 0) {
            // this means availabe is less than to be taken
            $deductionDays = $newBalance * -1;
        } else {
            $deductionDays = 0 ;
        }

        $objSalaryData = $this->hr_model->getCurrentMonthSalary($empid);

        $objEarning = $objSalaryData['earningInfo'];
        $objDeduction = $objSalaryData['deductionInfo'];
        $objEmployer = $objSalaryData['employerInfo'];

        $this->data["presentdays"] = $presentdays;
        $this->data["totaldays"] = $totaldays;
        $this->data["employeeid"] = $empid;
        $this->data["deductiondays"] = $deductionDays;
        $this->data["earningInfo"] = $objEarning;
        $this->data["deductionInfo"] = $objDeduction;
        $this->data["employerInfo"] = $objEmployer;

        $this->load->view('frontend/hr/employee-salary-adjust-edit', $this->data);
    }

    public function getemployeeLeaveBalance($empid)
    {
        $remainingLeaves = $this->hr_model->getemployeeLeaveBalance($empid);
        if (gettype($remainingLeaves) === 'boolean') {
            $finaldays = 0;
            return $finaldays;
        } else {
            $temp = $remainingLeaves[0];
            $finaldays = $temp->getAvailable();
            return $finaldays;
        }
    }

    public function salarystructureList()
    {
        $structureList = $this->hr_model->getSalaryStructureList();
        $this->data["title"]="Employee";
        $this->data["structureData"]=$structureList;
        $this->templateFront("frontend/hr/salary-structure-master-list", $this->data);
    }

    public function addNewSalaryStructure()
    {
        if (isset($_POST['submit'])) {
            $objResult = $this->hr_model->addNewSalaryStructure();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Salary Structure Saved Successfully.");
                redirect("hr/salarystructureList");
            } else {
                $this->session->set_flashdata('errorMsg', "This salary Type Already Exists, Please Use any Other Name.");
                redirect("hr/salarystructureList");
            }
        } else {
            redirect('hr/salarystructureList');
        }
    }

    public function deActivateSalaryMaster()
    {
        $id = $this->input->post('id');
        $this->hr_model->deActivateSalaryMaster($id);
        echo 1;
    }
    public function getSalaryById()
    {
        $id = $this->input->post('id');
        $objResult = $this->hr_model->getSalaryDetailsById($id);
        if ($objResult) {
            $this->data['masterData'] = $objResult[0];
            $this->load->view('frontend/hr/editSalaryStructure', $this->data);
        } else {
            return false;
        }
    }

    public function editSalaryStructure()
    {
        if (isset($_POST['submit'])) {
            $objResult = $this->hr_model->editSalaryStructure();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Salary Structure Updated Successfully.");
                redirect("hr/salarystructureList");
            } else {
                $this->session->set_flashdata('errorMsg', "This salary Type Already Exists, Please Use any Other Name.");
                redirect("hr/salarystructureList");
            }
        } else {
            redirect('hr/salarystructureList');
        }
    }

    public function yearlyHolidayMaster()
    {
        $holidayList = $this->hr_model->getyearlyHolidayMasterList();
        $this->data["title"]="Employee Yearly Holiday";
        if(gettype($holidayList) === 'boolean')
        {
           $holidayList = [];
        }
        $this->data["projectList"] = $this->project_model->getAllProjects();
        $this->data["holidayData"]=$holidayList;
        $this->templateFront("frontend/hr/yearly-holiday-list", $this->data);
    }

    public function getHolidayById()
    {
        $id = $this->input->post('id');
        $objResult = $this->hr_model->getHolidayDetailsById($id);
        if ($objResult) {
            $this->data["projectList"] = $this->project_model->getAllProjects();
            $this->data['masterData'] = $objResult[0];
            $this->load->view('frontend/hr/editHolidayMaster', $this->data);
        } else {
            return false;
        }
    }

    public function addEditHoliday()
    {
        if (isset($_POST['submit'])) {
          if(isset($_POST['holidayid']))
          {
            $objResult = $this->hr_model->editHoliday();
            if ($objResult) {
                $this->session->set_flashdata('successMsg', "Holiday Updated Successfully.");
                redirect("hr/yearlyHolidayMaster");
            } else {
                $this->session->set_flashdata('errorMsg', "This Holiday Already Exists, Please Use any Other Date.");
                redirect("hr/yearlyHolidayMaster");
            }
          }
          else {
              $objResult = $this->hr_model->addNewHoliday();
              if ($objResult) {
                  $this->session->set_flashdata('successMsg', "Holiday Saved Successfully.");
                  redirect("hr/yearlyHolidayMaster");
              } else {
                  $this->session->set_flashdata('errorMsg', "This Holiday Already Exists, Please Use any Other Date.");
                  redirect("hr/yearlyHolidayMaster");
              }
          }
      }
    }

    public function deActivateHolidayMaster()
    {
        $id = $this->input->post('id');
        $this->hr_model->deActivateHolidayMaster($id);
        echo 1;
    }

    public function deleteCurrentMonthSalary($id=null)
    {
        $objResult = $this->hr_model->deleteCurrentMonthSalary($id);
    }
    public function getIndianCurrency(float $number)
    {
        $decimal = round($number - ($no = floor($number)), 2) * 100;
        $hundred = null;
        $digits_length = strlen($no);
        $i = 0;
        $str = array();
        $words = array(0 => '', 1 => 'one', 2 => 'two',
        3 => 'three', 4 => 'four', 5 => 'five', 6 => 'six',
        7 => 'seven', 8 => 'eight', 9 => 'nine',
        10 => 'ten', 11 => 'eleven', 12 => 'twelve',
        13 => 'thirteen', 14 => 'fourteen', 15 => 'fifteen',
        16 => 'sixteen', 17 => 'seventeen', 18 => 'eighteen',
        19 => 'nineteen', 20 => 'twenty', 30 => 'thirty',
        40 => 'forty', 50 => 'fifty', 60 => 'sixty',
        70 => 'seventy', 80 => 'eighty', 90 => 'ninety');
        $digits = array('', 'hundred','thousand','lakh', 'crore');
        while ($i < $digits_length) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += $divider == 10 ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str [] = ($number < 21) ? $words[$number].' '. $digits[$counter]. $plural.' '.$hundred:$words[floor($number / 10) * 10].' '.$words[$number % 10]. ' '.$digits[$counter].$plural.' '.$hundred;
            } else {
                $str[] = null;
            }
        }
        $Rupees = implode('', array_reverse($str));
        $paise = ($decimal > 0) ? "." . ($words[$decimal / 10] . " " . $words[$decimal % 10]) . ' Paise' : '';
        return ($Rupees ? $Rupees . 'Rupees ' : '') . $paise;
    }
}
