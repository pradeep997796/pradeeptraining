<?php
//error_reporting(0);
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends TexBase {

	public function __construct() {
		parent :: __construct();
		$this->load->model('Auth_model','auth_model');
		$this->data["title"]="Login";
		$this->data["currentPage"]="login";
	}

	public function index() {
		redirect("auth/login");
	}

	public function login() {
		if($this->session->userdata("userId")) {
			redirect("dashboard");
		} else {
			$this->data["title"]="Login";
			if($this->input->server('REQUEST_METHOD') == 'POST') {
				$objResult=$this->auth_model->masterLogin($this->input->post('username'), $this->input->post('password'));
				if($objResult) {
					$this->session->set_userdata("userId", $objResult[0]->getId());
					$this->session->set_flashdata('successMsg', "Successfully login.");
					redirect("dashboard");
				} else {
					$this->session->set_flashdata('errorMsg', "Invalid username and password, try again.");
					redirect("auth/login");
				}
			} else {
				$this->load->view("frontend/auth/login", $this->data);
			}
		}	
	}
	
	public function logout() {
		$this->session->sess_destroy();
		redirect("auth/login");
	}
}
?>
