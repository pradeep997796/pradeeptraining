<?php
class SessionCheck {

    public $router;

    function __construct() {
    	//parent::__construct();
    	$this->CI = get_instance();
    	$this->CI->load->helper('url');
    	$this->router = & load_class('Router', 'core');
    }

    /**************************************************************************************************************
      Function name : adminSessionCheck
      @Description  : Add controller name to AuthController array, arrAllowMethods contains those methods for which we dont wish to check for session
     ***************************************************************************************************************/

    function adminSessionCheck() {
        $arrAllowMethods = array('login', 'forgotPassword');
        $arrAuthControllers = array('auth', 'dashboard', 'employee','project');

        if (in_array($this->router->fetch_class(), $arrAuthControllers) && (!in_array($this->router->fetch_method(), $arrAllowMethods))) {
			$checkSession = $this->CI->session->userdata('userId');
            if (!empty($checkSession)) {
				/** already login */
            } else {
				redirect('auth/login');
            }
        }
    }

}
