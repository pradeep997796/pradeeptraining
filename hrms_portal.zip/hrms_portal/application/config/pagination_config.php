<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Description of setting
 *
 * @author Neeta Mhatre
 */

$config['global_per_page'] = 10; //RECORDS_PER_PAGE_BACKOFFICE;
$config['pagination_design'] = array(
    'per_page' => $config['global_per_page'],
    'full_tag_open' => '<div class="pagination"><ul class="pagination mx-auto justify-content-center">',
    'full_tag_close' => '</ul></div>',
    'num_tag_open' => '<li class="page-item">',
    'num_tag_close' => '</li>',
    'cur_tag_open' => '<li class="page-item active"><a href="javascript:void(0);">',
    'cur_tag_close' => '</a></li>',
    'next_link' => 'Next',
    'next_tag_open' => '<li class="page-item">',
    'next_tag_close' => '</li>',
    'prev_link' => 'Prev',
    'prev_tag_open' => '<li class="page-item">',
    'prev_tag_close' => '</li>',
    'first_link' => 'First',
    'first_tag_open' => '<li class="page-item">',
    'first_tag_close' => '</li>',
    'last_link' => 'Last',
    'last_tag_open' => '<li class="page-item">',
    'last_tag_close' => '</li>',
    'use_page_numbers' => TRUE
);
$config['viewAllCategory'] = array_merge(array('base_url' => BASE_URL . 'category/index'),$config['pagination_design']);
$config['viewAllSubCategory'] = array_merge(array('base_url' => BASE_URL . 'category/subCategoryList'),$config['pagination_design']);
$config['viewAllProduct'] = array_merge(array('base_url' => BASE_URL . 'product/index'),$config['pagination_design']);
$config['viewAllAdmin'] = array_merge(array('base_url' => BASE_URL . 'admin/index'),$config['pagination_design']);
$config['viewAllScheme'] = array_merge(array('base_url' => BASE_URL . 'scheme/index'),$config['pagination_design']);
$config['viewAllRelatedProject'] = array_merge(array('base_url' => BASE_URL . 'product/relatedProductListing'),$config['pagination_design']);
$config['viewAllCustomer'] = array_merge(array('base_url' => BASE_URL . 'customer/index'),$config['pagination_design']);
$config['viewAllArtist'] = array_merge(array('base_url' => BASE_URL . 'artistManagement/index'),$config['pagination_design']);
$config['viewAllImageListing'] = array_merge(array('base_url' => BASE_URL . 'artistManagement/imageListing'),$config['pagination_design']);
?>