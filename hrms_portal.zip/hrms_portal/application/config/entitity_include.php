<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

 require_once(APPPATH . "Entities/EmployeeMaster.php");
 require_once(APPPATH . "Entities/ProjectMaster.php");
 require_once(APPPATH . "Entities/JobEmploymentMaster.php");
 require_once(APPPATH . "Entities/DocumentProofMaster.php");
 require_once(APPPATH . "Entities/AddressMaster.php");
 require_once(APPPATH . "Entities/FinanceInformation.php");
 require_once(APPPATH . "Entities/EducationalMaster.php");
 require_once(APPPATH . "Entities/EmergencyContactMaster.php");
 require_once(APPPATH . "Entities/DependentsMaster.php");
 require_once(APPPATH . "Entities/JobEmploymentMaster.php");
 require_once(APPPATH . "Entities/EmployeeInsuranceMaster.php");
 require_once(APPPATH . "Entities/EmployeeSalaryMaster.php");
 require_once(APPPATH . "Entities/SalaryStructureTypeMaster.php");
 require_once(APPPATH . "Entities/EmployeeMonthlySalaryMaster.php");
 require_once(APPPATH . "Entities/LeaveCodeMaster.php");
 require_once(APPPATH . "Entities/ProjectLeavesMaster.php");
 require_once(APPPATH . "Entities/EmployeeLeaveBalanceMaster.php");
 require_once(APPPATH . "Entities/EmployeeLeaveLogMaster.php");
 require_once(APPPATH . "Entities/EmployeeAccountMaster.php");
 require_once(APPPATH . "Entities/EmployeeYearlyHolidayMaster.php");
 require_once(APPPATH . "Entities/EmployeeMonthlyDeductionMaster.php");
 require_once(APPPATH . "Entities/EventMaster.php");
 require_once(APPPATH . "Entities/CountryMaster.php");
?>
