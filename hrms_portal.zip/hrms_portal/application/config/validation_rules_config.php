<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

// Array name    : adminLogin
// @Description  : Validates login form data
$config['adminLogin'] = array(
    array(
        'field' => 'email',
        'label' => 'email',
        'rules' => 'required|valid_email'
    ),
    array(
        'field' => 'password',
        'label' => 'password',
        'rules' => 'required|min_length[5]|max_length[20]'
    )
);
$config['addNewCategoryValidationRules'] = array(
    array(
        'field' => 'categoryname',
        'label' => 'category name',
        'rules' => 'required|max_length[100]'
    ),
    array(
        'field' => 'status',
        'label' => 'Status',
        'rules' => 'required'
    )
);
$config['editCategoryValidationRules'] = array(
    array(
        'field' => 'categoryname',
        'label' => 'category name',
        'rules' => 'required|max_length[100]'
    ),
    array(
        'field' => 'status',
        'label' => 'status',
        'rules' => 'required'
    )
);
$config['addNewSubCategoryValidationRules'] = array(
    array(
        'field' => 'categoryId[]',
        'label' => 'category name',
        'rules' => 'required|max_length[100]'
    ),
    array(
        'field' => 'subCategoryName',
        'label' => 'sub category name',
        'rules' => 'required|max_length[100]'
    )
);
$config['editSubCategoryValidationRules'] = array(
    array(
        'field' => 'categoryId[]',
        'label' => 'category name',
        'rules' => 'required|max_length[100]'
    ),
    array(
        'field' => 'subCategoryName',
        'label' => 'sub category name',
        'rules' => 'required'
    )
);
$config['addNewAdminValidation'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    ),
    array(
        'field' => 'email',
        'label' => 'email',
        'rules' => 'required|valid_email'
    ),
    array(
        'field' => 'password',
        'label' => 'password',
        'rules' => 'required|min_length[5]|max_length[20]'
    )
);
$config['addNewProductTypeValidationRules'] = array(
    array(
        'field' => 'productTypeName',
        'label' => 'product pype name',
        'rules' => 'required|max_length[100]'
    )
);
$config['editProductTypeValidationRules'] = array(
    array(
        'field' => 'productTypeName',
        'label' => 'product type name',
        'rules' => 'required|max_length[100]'
    )
);
$config['editAdminValidation'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    )
);

$config['addNewSchemeValidation'] = array(
    array(
        'field' => 'schemeTitle',
        'label' => 'scheme title',
        'rules' => 'required'
    ),
    array(
        'field' => 'schemeDescription',
        'label' => 'scheme description',
        'rules' => 'required'
    ),
    array(
        'field' => 'schemeBuyMethod',
        'label' => 'scheme buy method',
        'rules' => 'required'
    ),
    array(
        'field' => 'schemeTypeFor',
        'label' => 'scheme type for',
        'rules' => 'required'
    ),
    array(
        'field' => 'schemeType',
        'label' => 'scheme type',
        'rules' => 'required'
    ),
    array(
        'field' => 'totalImagesDownload',
        'label' => 'total images download',
        'rules' => 'required|numeric'
    ),  
    array(
        'field' => 'price',
        'label' => 'price',
        'rules' => 'required|numeric'
    ),
    array(
        'field' => 'pricePerImage',
        'label' => 'price per image',
        'rules' => 'required|numeric'
    ),
    array(
        'field' => 'schemeValidFrom',
        'label' => 'scheme valid from',
        'rules' => 'required'
    ),
    array(
        'field' => 'schemeValidTo',
        'label' => 'scheme valid to',
        'rules' => 'required'
    )
);

$config['addNewRelatedProductValidationRules'] = array(
    array(
        'field' => 'productTypeId[]',
        'label' => 'product type',
        'rules' => 'required'
    ),
    array(
        'field' => 'productName',
        'label' => 'related product name',
        'rules' => 'required'
    )
);

$config['editRelatedProductValidationRules'] = array(
    array(
        'field' => 'productTypeId[]',
        'label' => 'product type',
        'rules' => 'required'
    ),
    array(
        'field' => 'productName',
        'label' => 'related product name',
        'rules' => 'required'
    )
);

$config['addNewCustomerValidationRules'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    ),
    array(
        'field' => 'email',
        'label' => 'email',
        'rules' => 'required|valid_email'
    ),
    array(
        'field' => 'password',
        'label' => 'password',
        'rules' => 'required|min_length[5]|max_length[20]'
    ),
	array(
        'field' => 'mobileNumber',
        'label' => 'mobile number',
		'rules' => 'numeric|max_length[12]|min_length[10]'
    )
);

$config['editCustomerValidationRules'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    ),
	array(
        'field' => 'mobileNumber',
        'label' => 'mobile number',
		'rules' => 'numeric|max_length[12]|min_length[10]'
    )
);
$config['addNewArtistValidationRules'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    ),
    array(
        'field' => 'email',
        'label' => 'email',
        'rules' => 'required|valid_email'
    ),
    array(
        'field' => 'password',
        'label' => 'password',
        'rules' => 'required|min_length[5]|max_length[20]'
    ),
	array(
        'field' => 'mobileNumber',
        'label' => 'mobile number',
		'rules' => 'numeric|max_length[12]|min_length[10]'
    )
);
$config['editArtistValidationRules'] = array(
    array(
        'field' => 'firstname',
        'label' => 'first name',
        'rules' => 'required'
    ),
    array(
        'field' => 'lastname',
        'label' => 'last name',
        'rules' => 'required'
    ),
	array(
        'field' => 'mobileNumber',
        'label' => 'mobile number',
		'rules' => 'numeric|max_length[12]|min_length[10]'
    )
);


$config['addNewImageValidationRules'] = array(
	array(
        'field' => 'imageTitle',
        'label' => 'image title',
        'rules' => 'required'
    ),
	
	array(
        'field' => 'visibleFrom',
        'label' => 'visible from',
        'rules' => 'required'
    ),
	array(
        'field' => 'visibleTo',
        'label' => 'visible to',
        'rules' => 'required'
    ),
	array(
        'field' => 'imageKeyword',
        'label' => 'image keyword',
        'rules' => 'required'
    ),
	array(
        'field' => 'supportTechnology',
        'label' => 'support technology',
        'rules' => 'required'
    ),
	array(
        'field' => 'artistId',
        'label' => 'artist',
        'rules' => 'required'
    )
	/*array(
        'field' => 'imageName',
        'label' => 'image name',
		'rules' => 'callback_addNewImage'
    )*/
);
$config['editImageValidationRules']= array(
	array(
        'field' => 'imageTitle',
        'label' => 'image title',
        'rules' => 'required'
    ),
	
	array(
        'field' => 'visibleFrom',
        'label' => 'visible from',
        'rules' => 'required'
    ),
	array(
        'field' => 'visibleTo',
        'label' => 'visible to',
        'rules' => 'required'
    ),
	array(
        'field' => 'imageKeyword',
        'label' => 'image keyword',
        'rules' => 'required'
    ),
	array(
        'field' => 'supportTechnology',
        'label' => 'support technology',
        'rules' => 'required'
    ),
	array(
        'field' => 'artistId',
        'label' => 'artist',
        'rules' => 'required'
    )
	/*array(
        'field' => 'imageName',
        'label' => 'image name',
		'rules' => 'callback_upload_image'
    )*/
);
?>